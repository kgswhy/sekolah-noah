

<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Surat Tugas & Perjalanan Dinas</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item">Surat Tugas</li>
                    <li class="breadcrumb-item active" aria-current="page">Management Surat Tugas</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="ms-auto">
        <a href="<?php echo e(route('surat-tugas.create')); ?>" class="btn btn-primary">Ajukan Surat Tugas</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        
        <?php if(count($suratTugas) > 0): ?>
            <table id="suratTugasTable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Pegawai</th>
                        <th>Judul Tugas</th>
                        <th>Lokasi</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $suratTugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($tugas->id); ?></td>
                            <td><?php echo e($tugas->employee->full_name ?? '-'); ?></td>
                            <td><?php echo e($tugas->judul_tugas); ?></td>
                            <td><?php echo e($tugas->lokasi_tugas); ?></td>
                            <td>
                                <?php if($tugas->tanggal_selesai): ?>
                                    <?php echo e(\Carbon\Carbon::parse($tugas->tanggal_mulai)->format('d-m-Y')); ?> s.d. <?php echo e(\Carbon\Carbon::parse($tugas->tanggal_selesai)->format('d-m-Y')); ?>

                                <?php else: ?>
                                    <?php echo e(\Carbon\Carbon::parse($tugas->tanggal_mulai)->format('d-m-Y')); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($tugas->status === 'pending'): ?>
                                    <span class="badge bg-warning">Menunggu</span>
                                <?php elseif($tugas->status === 'approved'): ?>
                                    <span class="badge bg-success">Disetujui</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Ditolak</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('surat-tugas.show', $tugas->id)); ?>" class="btn btn-info btn-sm">Detail</a>

                                <?php if($tugas->status === 'pending'): ?>
                                    <?php if(Auth::user()->isApproverFor('surat-tugas')): ?>
                                        <a href="#" class="btn btn-success btn-sm"
                                            onclick="event.preventDefault(); document.getElementById('approve-form-<?php echo e($tugas->id); ?>').submit();">Setujui</a>
                                        <form id="approve-form-<?php echo e($tugas->id); ?>" 
                                            action="<?php echo e(route('surat-tugas.approve', $tugas->id)); ?>"
                                            method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>

                                        <a href="#" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#rejectModal<?php echo e($tugas->id); ?>">Tolak</a>

                                        <!-- Reject Modal -->
                                        <div class="modal fade" id="rejectModal<?php echo e($tugas->id); ?>" tabindex="-1"
                                            aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Alasan Penolakan</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="<?php echo e(route('surat-tugas.reject', $tugas->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body">
                                                            <div class="mb-3">
                                                                <label for="rejected_message"
                                                                    class="form-label">Alasan</label>
                                                                <textarea class="form-control" id="rejected_message" name="rejected_message" rows="3" required></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" class="btn btn-danger">Tolak</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(Auth::id() == $tugas->employee->user_id): ?>
                                        <a href="<?php echo e(route('surat-tugas.edit', $tugas->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                        <form action="<?php echo e(route('surat-tugas.destroy', $tugas->id)); ?>" method="POST" style="display: inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"
                                                onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="text-center py-5">
                <h4>Belum ada data pengajuan surat tugas</h4>
                <p>Silakan klik tombol "Ajukan Surat Tugas" untuk membuat pengajuan baru</p>
                <a href="<?php echo e(route('surat-tugas.create')); ?>" class="btn btn-primary mt-2">Ajukan Surat Tugas</a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function() {
        <?php if(count($suratTugas) > 0): ?>
            $('#suratTugasTable').DataTable();
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/surat-tugas/index.blade.php ENDPATH**/ ?>