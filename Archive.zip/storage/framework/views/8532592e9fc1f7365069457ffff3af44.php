<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Detail Pengajuan Lembur/Honor</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="/lembur-honor">Lembur dan Honor</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Detail</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                <th>Nama Lengkap</th>
                <td><?php echo e($lemburHonor->employee->full_name ?? '-'); ?></td>
            </tr>
            <tr>
                <th>Nomor Induk Karyawan</th>
                <td><?php echo e($lemburHonor->employee->nik ?? '-'); ?></td>
            </tr>
            <tr>
                <th>Unit</th>
                <td><?php echo e($lemburHonor->employee->unit ?? '-'); ?></td>
            </tr>
            <tr>
                <th>Divisi</th>
                <td><?php echo e($lemburHonor->employee->division ?? '-'); ?></td>
            </tr>
            <tr>
                <th>Status Karyawan</th>
                <td><?php echo e($lemburHonor->employee->employee_status ?? '-'); ?></td>
            </tr>
            <tr>
                <th>Jabatan</th>
                <td><?php echo e($lemburHonor->employee->position ?? '-'); ?></td>
            </tr>
            <tr>
                <th>Jenis Pengajuan</th>
                <td><?php echo e($lemburHonor->jenis == 'lembur' ? 'Lembur' : 'Honor Kegiatan'); ?></td>
            </tr>
            <tr>
                <th>Tanggal</th>
                <td>
                    <?php if($lemburHonor->tanggal_selesai): ?>
                        <?php echo e(\Carbon\Carbon::parse($lemburHonor->tanggal_mulai)->format('d-m-Y')); ?> s.d. <?php echo e(\Carbon\Carbon::parse($lemburHonor->tanggal_selesai)->format('d-m-Y')); ?>

                    <?php else: ?>
                        <?php echo e(\Carbon\Carbon::parse($lemburHonor->tanggal_mulai)->format('d-m-Y')); ?>

                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Waktu</th>
                <td>
                    <?php if($lemburHonor->waktu_mulai && $lemburHonor->waktu_selesai): ?>
                        <?php echo e($lemburHonor->waktu_mulai); ?> - <?php echo e($lemburHonor->waktu_selesai); ?>

                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Durasi (jam)</th>
                <td><?php echo e($lemburHonor->durasi ?? '-'); ?></td>
            </tr>
            <tr>
                <th>Kegiatan</th>
                <td><?php echo e($lemburHonor->kegiatan); ?></td>
            </tr>
            <tr>
                <th>Lokasi</th>
                <td><?php echo e($lemburHonor->lokasi); ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td>
                    <?php if($lemburHonor->status === 'pending'): ?>
                        <span class="badge bg-warning">Menunggu Persetujuan</span>
                    <?php elseif($lemburHonor->status === 'approved'): ?>
                        <span class="badge bg-success">Disetujui</span>
                    <?php else: ?>
                        <span class="text-danger">Ditolak: <?php echo e($lemburHonor->rejected_message); ?></span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Keterangan</th>
                <td><?php echo e($lemburHonor->keterangan ?? '-'); ?></td>
            </tr>
            <tr>
                <th>Dokumen Pendukung</th>
                <td>
                    <?php if($lemburHonor->dokumen_pendukung): ?>
                        <a href="<?php echo e(route('lembur-honor.preview', $lemburHonor->id)); ?>" target="_blank" class="btn btn-sm btn-info">
                            <i class="las la-eye"></i> Preview Dokumen
                        </a>
                        <a href="<?php echo e(route('lembur-honor.dokumen', $lemburHonor->id)); ?>" class="btn btn-sm btn-primary">
                            <i class="las la-download"></i> Download
                        </a>
                    <?php else: ?>
                        <span class="text-muted">Tidak ada dokumen</span>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        
        <div class="mt-3">
            <a href="<?php echo e(route('lembur-honor.index')); ?>" class="btn btn-secondary">Kembali</a>
            <?php if($lemburHonor->status === 'pending'): ?>
                <?php if(Auth::user()->isApproverFor('lembur')): ?>
                    <a href="#" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#approveModal">Setujui</a>
                    <a href="#" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal">Tolak</a>
                <?php endif; ?>
                <?php if(Auth::id() == $lemburHonor->employee->user_id): ?>
                    <a href="<?php echo e(route('lembur-honor.edit', $lemburHonor->id)); ?>" class="btn btn-warning">Edit</a>
                    <form action="<?php echo e(route('lembur-honor.destroy', $lemburHonor->id)); ?>" method="POST" style="display: inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Approve Modal -->
<div class="modal fade" id="approveModal" tabindex="-1" aria-labelledby="approveModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="approveModalLabel">Konfirmasi Persetujuan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('lembur-honor.approve', $lemburHonor->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    Apakah Anda yakin ingin menyetujui pengajuan lembur/honor ini?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Setujui</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="rejectModalLabel">Konfirmasi Penolakan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('lembur-honor.reject', $lemburHonor->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="rejected_message" class="form-label">Alasan Penolakan</label>
                        <textarea class="form-control" id="rejected_message" name="rejected_message" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-danger">Tolak</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/lembur-honor/detail.blade.php ENDPATH**/ ?>