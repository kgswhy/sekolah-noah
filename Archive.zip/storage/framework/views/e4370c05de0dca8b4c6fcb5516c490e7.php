<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Permintaan Design</h3>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                <li class="breadcrumb-item active">Permintaan Design</li>
            </ol>
        </nav>
    </div>
    <div class="ms-auto">
        <a href="<?php echo e(route('permintaan-design.create')); ?>" class="btn btn-primary">Buat Permintaan</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <table class="table table-bordered" id="designTable">
            <thead>
                <tr>
                    <th>Kategori</th>
                    <th>Unit</th>
                    <th>Divisi</th>
                    <th>Tanggal Deadline</th>
                    <th>Kegiatan</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->kategori); ?><?php if($item->kategori == 'lainnya' && $item->kategori_lainnya): ?> (<?php echo e($item->kategori_lainnya); ?>)<?php endif; ?></td>
                    <td><?php echo e($item->unit); ?></td>
                    <td><?php echo e($item->divisi); ?></td>
                    <td><?php echo e($item->tanggal_deadline); ?></td>
                    <td><?php echo e($item->kegiatan); ?></td>
                    <td><span class="badge bg-warning text-dark"><?php echo e($item->status); ?></span></td>
                    <td>
                        <a href="<?php echo e(route('permintaan-design.edit', $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('permintaan-design.destroy', $item->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm">Hapus</button>
                        </form>

                        
                        <button type="button" class="btn btn-success btn-sm"
                                                            
                        >Setuju
                    </button>
                    <button type="button" class="btn btn-danger btn-sm"
                        >
                        Tolak
                    </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function () {
        $('#designTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/permintaan-design/index.blade.php ENDPATH**/ ?>