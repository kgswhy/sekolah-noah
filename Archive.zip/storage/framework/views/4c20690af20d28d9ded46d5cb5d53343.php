

<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Izin Meninggalkan Pekerjaan (Brief)</h3>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                <li class="breadcrumb-item">HRD</li>
                <li class="breadcrumb-item active">Izin Brief</li>
            </ol>
        </nav>
    </div>
    <div class="ms-auto">
        <a href="/brief-absen/create" class="btn btn-primary">Ajukan Izin</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <table class="table table-bordered" id="briefTable">
            <thead>
                <tr>
                    <th>Nama Lengkap</th>
                    <th>Nomor Induk</th>
                    <th>Unit</th>
                    <th>Divisi</th>
                    <th>Status</th>
                    <th>Jabatan</th>
                    <th>Tanggal</th>
                    <th>Waktu</th>
                    <th>Keperluan</th>
                    <th>Dokumen</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Ari Wibowo</td>
                    <td>EMP001</td>
                    <td>Kantor Pusat</td>
                    <td>Keuangan</td>
                    <td>Tetap</td>
                    <td>Staf Keuangan</td>
                    <td>2025-04-20</td>
                    <td>10:00 - 12:00</td>
                    <td>Urusan keluarga</td>
                    <td><a href="#">Lihat</a></td>
                    <td>
                        <a href="#" class="btn btn-warning btn-sm">Edit</a>
                        <a href="#" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?');">Delete</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function () {
        $('#briefTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u803666018/domains/mudamudiworks.com/public_html/sekolah-noah/server/resources/views/pages/izin-brief/index.blade.php ENDPATH**/ ?>