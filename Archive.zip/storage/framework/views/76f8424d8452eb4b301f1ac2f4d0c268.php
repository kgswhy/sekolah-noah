

<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Detail SOP</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="/sops">SOP</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Detail SOP</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="ms-auto">
        <a href="/sops/edit/1" class="btn btn-warning">Edit SOP</a>
        <a href="/sops" class="btn btn-secondary">Kembali</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <!-- Card untuk Detail SOP -->
        <div class="card">
            <div class="card-body">
                <!-- Data Dummy SOP -->
                <h5><strong>ID:</strong> 1</h5>
                <h5><strong>Judul:</strong> SOP Pengajuan Cuti</h5>
                <h5><strong>Isi:</strong></h5>
                <p>
                    SOP Pengajuan Cuti ini bertujuan untuk memberikan panduan kepada semua karyawan dalam mengajukan permohonan cuti, 
                    baik itu cuti tahunan, sakit, atau cuti lainnya. Proses ini melibatkan beberapa langkah yang harus dilakukan oleh karyawan 
                    dan atasan untuk memastikan kelancaran pengajuan dan persetujuan cuti. Berikut adalah langkah-langkah yang harus dilakukan:
                </p>
                <ul>
                    <li>Langkah 1: Karyawan mengisi formulir permohonan cuti yang tersedia di sistem HRIS.</li>
                    <li>Langkah 2: Permohonan cuti diajukan untuk disetujui oleh atasan langsung.</li>
                    <li>Langkah 3: Setelah persetujuan dari atasan, HRD akan memproses permohonan dan mencatatnya dalam sistem.</li>
                    <li>Langkah 4: Karyawan akan menerima konfirmasi pengajuan cuti yang telah disetujui atau ditolak.</li>
                </ul>
                <p>
                    SOP ini wajib dipatuhi oleh seluruh karyawan dan diharapkan dapat meningkatkan efisiensi dalam pengelolaan cuti di perusahaan.
                </p>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u803666018/domains/mudamudiworks.com/public_html/sekolah-noah/server/resources/views/pages/sop/detail.blade.php ENDPATH**/ ?>