

<?php $__env->startSection('content-header'); ?>
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h3 class="page-title">Lembur dan Honor Kegiatan</h3>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item active">Lembur dan Honor</li>
                </ol>
            </nav>
        </div>
        <div class="ms-auto">
            <a href="<?php echo e(route('lembur-honor.create')); ?>" class="btn btn-primary">Ajukan Lembur/Honor</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <?php if(count($lemburHonors) > 0): ?>
                <table class="table table-bordered" id="lemburTable">
                    <thead>
                        <tr>
                            <th>Nama Pegawai</th>
                            <th>Nomor Induk</th>
                            <th>Unit</th>
                            <th>Divisi</th>
                            <th>Jenis</th>
                            <th>Tanggal</th>
                            <th>Kegiatan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $lemburHonors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lemburHonor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($lemburHonor->employee->full_name ?? '-'); ?></td>
                                <td><?php echo e($lemburHonor->employee->nik ?? '-'); ?></td>
                                <td><?php echo e($lemburHonor->employee->unit ?? '-'); ?></td>
                                <td><?php echo e($lemburHonor->employee->division ?? '-'); ?></td>
                                <td><?php echo e($lemburHonor->jenis == 'lembur' ? 'Lembur' : 'Honor'); ?></td>
                                <td>
                                    <?php if($lemburHonor->tanggal_selesai): ?>
                                        <?php echo e(\Carbon\Carbon::parse($lemburHonor->tanggal_mulai)->format('d-m-Y')); ?> s.d.
                                        <?php echo e(\Carbon\Carbon::parse($lemburHonor->tanggal_selesai)->format('d-m-Y')); ?>

                                    <?php else: ?>
                                        <?php echo e(\Carbon\Carbon::parse($lemburHonor->tanggal_mulai)->format('d-m-Y')); ?>

                                    <?php endif; ?>
                                </td>
                                
                                <td><?php echo e($lemburHonor->kegiatan); ?></td>
                                <td>
                                    <?php if($lemburHonor->status == 'pending'): ?>
                                        <span class="badge bg-warning">Menunggu</span>
                                    <?php elseif($lemburHonor->status == 'approved'): ?>
                                        <span class="badge bg-success">Disetujui</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Ditolak</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('lembur-honor.show', $lemburHonor->id)); ?>"
                                        class="btn btn-info btn-sm">Detail</a>

                                    <?php if($lemburHonor->status == 'pending'): ?>
                                        <?php if(Auth::user()->isApproverFor('lembur')): ?>
                                            <a href="#" class="btn btn-success btn-sm"
                                                onclick="event.preventDefault(); document.getElementById('approve-form-<?php echo e($lemburHonor->id); ?>').submit();">Setujui</a>
                                            <form id="approve-form-<?php echo e($lemburHonor->id); ?>"
                                                action="<?php echo e(route('lembur-honor.approve', $lemburHonor->id)); ?>"
                                                method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                            </form>

                                            <a href="#" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                                data-bs-target="#rejectModal<?php echo e($lemburHonor->id); ?>">Tolak</a>

                                            <!-- Reject Modal -->
                                            <div class="modal fade" id="rejectModal<?php echo e($lemburHonor->id); ?>" tabindex="-1"
                                                aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Alasan Penolakan</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <form action="<?php echo e(route('lembur-honor.reject', $lemburHonor->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-body">
                                                                <div class="mb-3">
                                                                    <label for="rejected_message"
                                                                        class="form-label">Alasan</label>
                                                                    <textarea class="form-control" id="rejected_message" name="rejected_message" rows="3" required></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Batal</button>
                                                                <button type="submit" class="btn btn-danger">Tolak</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <?php if(Auth::id() == $lemburHonor->employee->user_id): ?>
                                            <a href="<?php echo e(route('lembur-honor.edit', $lemburHonor->id)); ?>"
                                                class="btn btn-warning btn-sm">Edit</a>
                                            <form action="<?php echo e(route('lembur-honor.destroy', $lemburHonor->id)); ?>"
                                                method="POST" style="display: inline-block">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm"
                                                    onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                                            </form>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="text-center py-5">
                    <h4>Belum ada data pengajuan lembur/honor</h4>
                    <p>Silakan klik tombol "Ajukan Lembur/Honor" untuk membuat pengajuan baru</p>
                    <a href="<?php echo e(route('lembur-honor.create')); ?>" class="btn btn-primary mt-2">Ajukan Lembur/Honor</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready(function() {
            <?php if(count($lemburHonors) > 0): ?>
                $('#lemburTable').DataTable();
            <?php endif; ?>
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/lembur-honor/index.blade.php ENDPATH**/ ?>