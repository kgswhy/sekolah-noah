<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Edit Alur Persetujuan: <?php echo e($workflow->display_name); ?></h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item">Pengaturan</li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('approval.index')); ?>">Alur Persetujuan</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Detail Alur Persetujuan</h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('approval.update-workflow', $workflow->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="row mb-3">
                        <label for="module_name" class="col-sm-3 col-form-label">Modul Persetujuan</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" value="<?php echo e($workflow->module_name); ?>" readonly disabled>
                            <small class="form-text text-muted">Modul tidak dapat diubah setelah dibuat.</small>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <label for="display_name" class="col-sm-3 col-form-label">Nama Alur Persetujuan <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control <?php $__errorArgs = ['display_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="display_name" name="display_name" value="<?php echo e(old('display_name', $workflow->display_name)); ?>" required>
                            <?php $__errorArgs = ['display_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <label for="description" class="col-sm-3 col-form-label">Deskripsi</label>
                        <div class="col-sm-9">
                            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description" name="description" rows="3"><?php echo e(old('description', $workflow->description)); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-sm-9 offset-sm-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" <?php echo e(old('is_active', $workflow->is_active) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="is_active">
                                    Aktifkan Alur Persetujuan
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-sm-9 offset-sm-3">
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="card mt-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="card-title">Langkah-langkah Persetujuan</h4>
                <a href="<?php echo e(route('approval.create-step', $workflow->id)); ?>" class="btn btn-primary">
                    <i class="las la-plus"></i> Tambah Langkah
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="stepsTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="5%">Urutan</th>
                                <th width="25%">Nama Langkah</th>
                                <th width="20%">Tipe Persetujuan</th>
                                <th width="20%">Pemberi Persetujuan</th>
                                <th width="10%">Status</th>
                                <th width="20%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $workflow->steps->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($step->order); ?></td>
                                <td><?php echo e($step->name); ?></td>
                                <td>
                                    <?php if($step->approval_type == 'user'): ?>
                                        Berdasarkan User
                                    <?php elseif($step->approval_type == 'role'): ?>
                                        Berdasarkan Role
                                    <?php elseif($step->approval_type == 'department'): ?>
                                        Berdasarkan Departemen
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($step->approval_type == 'user'): ?>
                                        <?php $__currentLoopData = $step->approvers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-primary"><?php echo e($approver->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php elseif($step->approval_type == 'role'): ?>
                                        <?php $__currentLoopData = json_decode($step->getAttributes()['approvers']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approverId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-info">Role <?php echo e($approverId); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php elseif($step->approval_type == 'department'): ?>
                                        <?php $__currentLoopData = json_decode($step->getAttributes()['approvers']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approverId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-secondary">Dept <?php echo e($approverId); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($step->is_active): ?>
                                    <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                    <span class="badge bg-danger">Tidak Aktif</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('approval.edit-step', ['workflow' => $workflow->id, 'step' => $step->id])); ?>" class="btn btn-info btn-sm">
                                        <i class="las la-edit"></i> Edit
                                    </a>
                                    <a href="#" class="btn btn-danger btn-sm" 
                                       onclick="event.preventDefault(); if(confirm('Apakah Anda yakin ingin menghapus langkah ini?')) document.getElementById('delete-step-<?php echo e($step->id); ?>').submit();">
                                        <i class="las la-trash"></i> Hapus
                                    </a>
                                    <form id="delete-step-<?php echo e($step->id); ?>" action="<?php echo e(route('approval.delete-step', ['workflow' => $workflow->id, 'step' => $step->id])); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">Belum ada langkah persetujuan yang ditambahkan</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="mt-4">
                    <div class="alert alert-info">
                        <i class="las la-info-circle"></i> Langkah-langkah persetujuan akan diproses sesuai dengan urutan yang ditentukan.
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card mt-4">
            <div class="card-header">
                <h4 class="card-title">Panduan Pengaturan Langkah Persetujuan</h4>
            </div>
            <div class="card-body">
                <h5>Tips Pengaturan Langkah Persetujuan:</h5>
                <ol>
                    <li>Urutkan langkah persetujuan sesuai dengan hierarki organisasi</li>
                    <li>Setiap langkah dapat memiliki satu atau beberapa pemberi persetujuan</li>
                    <li>Anda dapat menentukan apakah semua pemberi persetujuan harus menyetujui atau hanya salah satu saja</li>
                    <li>Nonaktifkan langkah yang tidak diperlukan tanpa perlu menghapusnya</li>
                </ol>
                
                <div class="mt-3">
                    <a href="<?php echo e(route('approval.index')); ?>" class="btn btn-secondary">Kembali ke Daftar Alur Persetujuan</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/approvals/edit-workflow.blade.php ENDPATH**/ ?>