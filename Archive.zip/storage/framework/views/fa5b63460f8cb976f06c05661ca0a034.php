

<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Management Cuti</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item">Cuti</li>
                    <li class="breadcrumb-item active" aria-current="page">Management Cuti</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="ms-auto">
        <a href="/cuti/create" class="btn btn-primary">Ajukan Cuti</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <table id="cutiTable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama Karyawan</th>
                            <th>NIK</th>
                            <th>Tanggal Cuti</th>
                            <th>Alasan</th>
                            <th>Status</th>
                            <th>Approval</th>  <!-- New column for approval -->
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cutis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($cuti->id); ?></td>
                                <td><?php echo e($cuti->employee->full_name ?? '-'); ?></td>
                                <td><?php echo e($cuti->employee->nik ?? '-'); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($cuti->tanggal_mulai)->format('d-m-Y')); ?> s.d. <?php echo e(\Carbon\Carbon::parse($cuti->tanggal_selesai)->format('d-m-Y')); ?></td>
                                <td><?php echo e($cuti->alasan); ?></td>
                                <td>
                                    <?php if($cuti->status === 'pending'): ?>
                                        <span class="badge bg-warning">Menunggu Persetujuan</span>
                                    <?php elseif($cuti->status === 'approved'): ?>
                                        <span class="badge bg-success">Disetujui</span>
                                    <?php else: ?>
                                        <span class="text-danger">Ditolak: <?php echo e($cuti->rejected_message); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($cuti->status === 'pending'): ?>
                                        <a href="<?php echo e(route('cuti.approve', $cuti->id)); ?>" class="btn btn-success btn-sm">Terima</a>

                                        <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#rejectModal-<?php echo e($cuti->id); ?>">
                                            Tolak
                                        </button>

                                        <div class="modal fade" id="rejectModal-<?php echo e($cuti->id); ?>" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <form action="<?php echo e(route('cuti.reject', $cuti->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                    <h5 class="modal-title">Tolak Pengajuan Cuti</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label for="rejected_message" class="form-label">Alasan Penolakan</label>
                                                        <textarea name="rejected_message" class="form-control" required></textarea>
                                                    </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                    <button type="submit" class="btn btn-danger">Tolak</button>
                                                    </div>
                                                </div>
                                                </form>
                                            </div>
                                        </div>

                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('cuti.edit', $cuti->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="<?php echo e(route('cuti.show', $cuti->id)); ?>" class="btn btn-info btn-sm">Detail</a>
                                    <form action="<?php echo e(route('cuti.destroy', $cuti->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus pengajuan cuti ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function() {
        $('#cutiTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u803666018/domains/mudamudiworks.com/public_html/sekolah-noah/server/resources/views/pages/cuti/index.blade.php ENDPATH**/ ?>