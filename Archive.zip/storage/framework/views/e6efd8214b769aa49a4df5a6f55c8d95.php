<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Kelola Hak Akses: <?php echo e($user->name); ?></h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item">Pengaturan</li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('user-permissions.index')); ?>">Hak Akses</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($user->name); ?></li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Detail Pengguna</h4>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <p><strong>Nama:</strong> <?php echo e($user->name); ?></p>
                        <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                    </div>
                    <div class="col-md-6">
                        <?php if($user->employee): ?>
                        <p><strong>NIK:</strong> <?php echo e($user->employee->nik ?? '-'); ?></p>
                        <p><strong>Jabatan:</strong> <?php echo e($user->employee->position ?? '-'); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="card-title">Pengaturan Hak Akses Menu</h4>
                <div>
                    <button type="button" class="btn btn-success btn-sm" id="selectAll">Pilih Semua</button>
                    <button type="button" class="btn btn-danger btn-sm" id="deselectAll">Batalkan Semua</button>
                </div>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('user-permissions.update', $user->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th width="50%">Menu</th>
                                    <th width="25%">Akses (Radio)</th>
                                    <th width="25%">Akses (Dropdown)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Main sections -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>Dashboard & Menu Utama</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['dashboard']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_yes" value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_yes">Ya</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_no" value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_no">Tidak</label>
                                        </div>
                                    </td>
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Student section -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>Manajemen Siswa</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['students']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_yes" value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_yes">Ya</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_no" value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_no">Tidak</label>
                                        </div>
                                    </td>
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Employee section -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>Manajemen Kepegawaian</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['employee', 'salary_components', 'absence', 'payroll', 'shifts', 'schedules', 'kinerja']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_yes" value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_yes">Ya</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_no" value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_no">Tidak</label>
                                        </div>
                                    </td>
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- HR requests -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>Pengajuan Kepegawaian</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['cuti', 'brief_absen', 'klaim_berobat', 'slip_gaji_skk', 'pinjaman_cicilan', 'lembur_honor', 'surat_tugas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_yes" value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_yes">Ya</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_no" value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_no">Tidak</label>
                                        </div>
                                    </td>
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- IT section -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>IT</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['fixing_request', 'equipment_loan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_yes" value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_yes">Ya</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_no" value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_no">Tidak</label>
                                        </div>
                                    </td>
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Operations -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>Operasional</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['barang', 'pengecekan_barang', 'kurir_mobil', 'peminjaman']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_yes" value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_yes">Ya</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_no" value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_no">Tidak</label>
                                        </div>
                                    </td>
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Administration -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>Administrasi</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['request_fotocopy', 'surat_masuk', 'surat_keluar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_yes" value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_yes">Ya</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_no" value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_no">Tidak</label>
                                        </div>
                                    </td>
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Finance -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>Keuangan</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['pembayaran_siswa', 'aktiva_tetap', 'pengajuan_dana_bank']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_yes" value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_yes">Ya</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_no" value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_no">Tidak</label>
                                        </div>
                                    </td>
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Admission -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>Penerimaan Siswa</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['admission_pendaftaran', 'admission_kegiatan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_yes" value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_yes">Ya</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_no" value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_no">Tidak</label>
                                        </div>
                                    </td>
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Document Management -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>Manajemen Dokumen</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['dms', 'sop', 'regulasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_yes" value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_yes">Ya</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_no" value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_no">Tidak</label>
                                        </div>
                                    </td>
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Other features -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>Lainnya</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['users', 'calendar', 'pengumuman', 'kelas', 'permintaan_design']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_yes" value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_yes">Ya</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="permissions[<?php echo e($key); ?>]" id="<?php echo e($key); ?>_no" value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($key); ?>_no">Tidak</label>
                                        </div>
                                    </td>
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Settings -->
                                <tr class="bg-light">
                                    <td colspan="3"><strong>Pengaturan</strong></td>
                                </tr>
                                <?php $__currentLoopData = ['settings_approval', 'settings_general']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menus[$key]); ?></td>
                                    
                                    <td>
                                        <select class="form-select" name="permissions[<?php echo e($key); ?>]" id="select_<?php echo e($key); ?>">
                                            <option value="1" <?php echo e(isset($currentPermissions[$key]) && $currentPermissions[$key] ? 'selected' : ''); ?>>Ya - Dapat Akses</option>
                                            <option value="0" <?php echo e(!isset($currentPermissions[$key]) || !$currentPermissions[$key] ? 'selected' : ''); ?>>Tidak</option>
                                        </select>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-end mt-3">
                        <a href="<?php echo e(route('user-permissions.index')); ?>" class="btn btn-secondary me-2">Kembali</a>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Synchronize radio buttons and dropdowns
        $('input[type=radio]').change(function() {
            var name = $(this).attr('name');
            var value = $(this).val();
            $('select[name="' + name + '"]').val(value);
        });

        $('select').change(function() {
            var name = $(this).attr('name');
            var value = $(this).val();
            $('input[name="' + name + '"][value="' + value + '"]').prop('checked', true);
        });

        // Select all function
        $('#selectAll').click(function() {
            $('input[type=radio][value="1"]').prop('checked', true);
            $('select').val(1);
        });

        // Deselect all function
        $('#deselectAll').click(function() {
            $('input[type=radio][value="0"]').prop('checked', true);
            $('select').val(0);
        });
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/user-permissions/edit.blade.php ENDPATH**/ ?>