<?php $__env->startSection('header'); ?>
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h3 class="page-title">Detail Permintaan Perbaikan</h3>
            <div class="d-inline-block align-items-center">
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('fixing-request.index')); ?>"><i class="mdi mdi-home-outline"></i></a></li>
                        <li class="breadcrumb-item" aria-current="page">IT</li>
                        <li class="breadcrumb-item" aria-current="page">Permintaan Perbaikan</li>
                        <li class="breadcrumb-item active" aria-current="page">Detail</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="box">
                <div class="box-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="fw-bold">Tanggal Pengajuan</label>
                                <p><?php echo e($fixingRequest->created_at->format('d-m-Y H:i')); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="fw-bold">Status</label>
                                <p>
                                    <?php if($fixingRequest->status == 'pending'): ?>
                                        <span class="badge bg-warning">Menunggu</span>
                                    <?php elseif($fixingRequest->status == 'approved'): ?>
                                        <span class="badge bg-success">Disetujui</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Ditolak</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="fw-bold">Kategori Perangkat</label>
                                <p><?php echo e($fixingRequest->device_category); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="fw-bold">Nama User</label>
                                <p><?php echo e($fixingRequest->user->employee->full_name); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="fw-bold">Unit</label>
                                <p><?php echo e($fixingRequest->unit); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="fw-bold">Divisi</label>
                                <p><?php echo e($fixingRequest->division); ?></p>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="fw-bold">Rincian Kerusakan</label>
                                <p><?php echo e($fixingRequest->damage_details); ?></p>
                            </div>
                        </div>
                        <?php if($fixingRequest->supporting_document): ?>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="fw-bold">Dokumen Pendukung</label>
                                    <p>
                                        <a href="<?php echo e(asset('storage/' . $fixingRequest->supporting_document)); ?>" target="_blank" class="btn btn-info btn-sm">
                                            <i class="mdi mdi-download"></i> Download Dokumen
                                        </a>
                                    </p>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($fixingRequest->status == 'rejected' && $fixingRequest->rejected_message): ?>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="fw-bold">Alasan Penolakan</label>
                                    <p class="text-danger"><?php echo e($fixingRequest->rejected_message); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="mt-4">
                        <a href="<?php echo e(route('fixing-request.index')); ?>" class="btn btn-secondary">
                            <i class="mdi mdi-arrow-left"></i> Kembali
                        </a>
                        <?php if($fixingRequest->status == 'pending' && Auth::user()->hasRole('admin')): ?>
                            <form action="<?php echo e(route('fixing-request.approve', $fixingRequest->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-success" onclick="return confirm('Apakah Anda yakin ingin menyetujui request ini?')">
                                    <i class="mdi mdi-check"></i> Setujui
                                </button>
                            </form>
                            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal">
                                <i class="mdi mdi-close"></i> Tolak
                            </button>
                        <?php endif; ?>
                        <?php if($fixingRequest->status == 'pending' || Auth::user()->hasRole('admin')): ?>
                            <form action="<?php echo e(route('fixing-request.destroy', $fixingRequest->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus request ini?')">
                                    <i class="mdi mdi-delete"></i> Hapus
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Reject Modal -->
    <div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('fixing-request.reject', $fixingRequest->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="rejectModalLabel">Tolak Request</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="rejection_message">Alasan Penolakan</label>
                            <textarea class="form-control" id="rejection_message" name="rejection_message" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-danger">Tolak Request</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/fixing-request/show.blade.php ENDPATH**/ ?>