<?php $__env->startSection('content-header'); ?>
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h3 class="page-title">Detail Peminjaman Ruangan</h3>
            <div class="d-inline-block align-items-center">
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                        <li class="breadcrumb-item" aria-current="page">Peminjaman Ruangan</li>
                        <li class="breadcrumb-item active" aria-current="page">Detail</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="ms-auto">
            <a href="<?php echo e(route('peminjaman.index')); ?>" class="btn btn-secondary">
                <i class="las la-arrow-left"></i> Kembali
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 offset-md-2">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Informasi Peminjaman</h5>
            </div>
            <div class="card-body">
                <table class="table table-borderless mb-0">
                    <tr>
                        <th width="35%">Nama Karyawan</th>
                        <td><?php echo e($peminjaman->nama_karyawan); ?></td>
                    </tr>
                    <tr>
                        <th>Unit</th>
                        <td><?php echo e($peminjaman->unit); ?></td>
                    </tr>
                    <tr>
                        <th>Departemen</th>
                        <td><?php echo e($peminjaman->departemen); ?></td>
                    </tr>
                    <tr>
                        <th>Tanggal Pengajuan</th>
                        <td><?php echo e($peminjaman->tanggal_pengajuan); ?></td>
                    </tr>
                    <tr>
                        <th>Tanggal Diperlukan</th>
                        <td><?php echo e($peminjaman->tanggal_diperlukan); ?></td>
                    </tr>
                    <tr>
                        <th>Waktu Pelaksanaan</th>
                        <td><?php echo e($peminjaman->waktu_pelaksanaan); ?></td>
                    </tr>
                    <tr>
                        <th>Nama Kegiatan</th>
                        <td><?php echo e($peminjaman->nama_kegiatan); ?></td>
                    </tr>
                    <tr>
                        <th>Tempat Kegiatan</th>
                        <td><?php echo e($peminjaman->tempat_kegiatan); ?></td>
                    </tr>
                    <tr>
                        <th>Ruangan</th>
                        <td>
                            <ul class="mb-0">
                                <?php $__currentLoopData = json_decode($peminjaman->ruangan); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $ruang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <strong><?php echo e($ruang); ?></strong>
                                        <br>
                                        Jumlah: <?php echo e(json_decode($peminjaman->jumlah)[$i] ?? '-'); ?><br>
                                        Keterangan: <?php echo e(json_decode($peminjaman->keterangan)[$i] ?? '-'); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/peminjaman-ruangan/show.blade.php ENDPATH**/ ?>