<?php $__env->startSection('title', 'Detail Peminjaman Peralatan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('equipment-loan.index')); ?>">Peminjaman Peralatan</a></li>
                        <li class="breadcrumb-item active">Detail</li>
                    </ol>
                </div>
                <h4 class="page-title">Detail Peminjaman Peralatan</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Nama Peralatan</label>
                                <p class="form-control-static"><?php echo e($equipmentLoan->equipment_name); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Unit</label>
                                <p class="form-control-static"><?php echo e($equipmentLoan->unit); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Divisi</label>
                                <p class="form-control-static"><?php echo e($equipmentLoan->division); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Tanggal Pinjam</label>
                                <p class="form-control-static"><?php echo e($equipmentLoan->loan_date->format('d/m/Y')); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Tanggal Kembali</label>
                                <p class="form-control-static"><?php echo e($equipmentLoan->return_date->format('d/m/Y')); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Tujuan Peminjaman</label>
                                <p class="form-control-static"><?php echo e($equipmentLoan->purpose); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <p class="form-control-static">
                                    <?php if($equipmentLoan->status === 'pending'): ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php elseif($equipmentLoan->status === 'approved'): ?>
                                        <span class="badge bg-success">Disetujui</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Ditolak</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                            <?php if($equipmentLoan->status === 'approved'): ?>
                                <div class="mb-3">
                                    <label class="form-label">Disetujui Oleh</label>
                                    <p class="form-control-static"><?php echo e($equipmentLoan->approver->name); ?></p>
                                </div>
                            <?php endif; ?>
                            <?php if($equipmentLoan->status === 'rejected'): ?>
                                <div class="mb-3">
                                    <label class="form-label">Ditolak Oleh</label>
                                    <p class="form-control-static"><?php echo e($equipmentLoan->rejecter->name); ?></p>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Alasan Penolakan</label>
                                    <p class="form-control-static"><?php echo e($equipmentLoan->rejected_message); ?></p>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Tanggal Penolakan</label>
                                    <p class="form-control-static"><?php echo e($equipmentLoan->rejected_at->format('d/m/Y H:i')); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-12">
                            <a href="<?php echo e(route('equipment-loan.index')); ?>" class="btn btn-secondary">Kembali</a>
                            <?php if($equipmentLoan->status === 'pending' && Auth::user()->hasRole('admin')): ?>
                                <form action="<?php echo e(route('equipment-loan.approve', $equipmentLoan)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success" onclick="return confirm('Apakah Anda yakin ingin menyetujui permintaan ini?')">
                                        Setujui
                                    </button>
                                </form>
                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rejectModal">
                                    Tolak
                                </button>
                            <?php endif; ?>
                            <?php if(($equipmentLoan->status === 'pending' && Auth::id() === $equipmentLoan->user_id) || Auth::user()->hasRole('admin')): ?>
                                <form action="<?php echo e(route('equipment-loan.destroy', $equipmentLoan)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus permintaan ini?')">
                                        Hapus
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('equipment-loan.reject', $equipmentLoan)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="rejectModalLabel">Tolak Permintaan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="rejected_message" class="form-label">Alasan Penolakan</label>
                        <textarea class="form-control" id="rejected_message" name="rejected_message" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-danger">Tolak</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/equipment-loan/show.blade.php ENDPATH**/ ?>