<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Pengaturan Workflow Approval</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item">Pengaturan</li>
                    <li class="breadcrumb-item active">Workflow Approval</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Konfigurasi Workflow Approval</h4>
                <p class="text-muted">Tentukan alur persetujuan untuk tiap modul dan tipe departemen</p>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                
                <!-- Workflow Configuration Form -->
                <form id="workflowForm" action="<?php echo e(route('settings.workflow.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Modul:</label>
                                <select id="moduleSelect" class="form-control" name="module" required>
                                    <option value="">-- Pilih Modul --</option>
                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($module); ?>"><?php echo e(ucfirst($module)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Tipe Departemen:</label>
                                <select id="departmentTypeSelect" class="form-control" name="department_type" required>
                                    <option value="">-- Pilih Tipe Departemen --</option>
                                    <?php $__currentLoopData = $departmentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type); ?>"><?php echo e(ucfirst($type)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Approval Levels Configuration -->
                    <div id="approvalLevelsSection" class="d-none">
                        <h5 class="border-bottom pb-2 mb-3">Konfigurasi Level Approval</h5>
                        
                        <div id="approvalLevels">
                            <!-- Approval levels will be added here dynamically -->
                        </div>
                        
                        <div class="row mt-3 mb-4">
                            <div class="col-12">
                                <button type="button" id="addLevelBtn" class="btn btn-sm btn-outline-primary">
                                    <i class="las la-plus"></i> Tambah Level Approval
                                </button>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">Simpan Konfigurasi</button>
                            </div>
                        </div>
                    </div>
                </form>
                
                <!-- Current Workflows Table -->
                <div class="mt-5">
                    <h5 class="border-bottom pb-2 mb-3">Workflow yang Aktif</h5>
                    
                    <?php if($workflows->isEmpty()): ?>
                        <div class="alert alert-info">
                            Belum ada workflow approval yang dikonfigurasi.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Modul</th>
                                        <th>Tipe Departemen</th>
                                        <th>Jumlah Level</th>
                                        <th>Detail</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $workflows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workflow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($workflow->name); ?></td>
                                            <td><?php echo e(ucfirst($workflow->module)); ?></td>
                                            <td><?php echo e(ucfirst($workflow->department_type)); ?></td>
                                            <td><?php echo e(count($workflow->approval_flow)); ?></td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-info view-workflow-btn" 
                                                    data-module="<?php echo e($workflow->module); ?>" 
                                                    data-department-type="<?php echo e($workflow->department_type); ?>">
                                                    <i class="las la-eye"></i> Lihat
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Workflow Detail Modal -->
<div class="modal fade" id="workflowDetailModal" tabindex="-1" aria-labelledby="workflowDetailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="workflowDetailModalLabel">Detail Workflow</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="workflowDetailContent">
                    <!-- Workflow details will be loaded here -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize Select2 for better user selection
        if($.fn.select2) {
            $('.select2').select2();
        }
        
        // Handle module and department type selection
        const moduleSelect = document.getElementById('moduleSelect');
        const departmentTypeSelect = document.getElementById('departmentTypeSelect');
        const approvalLevelsSection = document.getElementById('approvalLevelsSection');
        const approvalLevels = document.getElementById('approvalLevels');
        const addLevelBtn = document.getElementById('addLevelBtn');
        
        // Check if both module and department type are selected
        function checkSelections() {
            if (moduleSelect.value && departmentTypeSelect.value) {
                loadExistingWorkflow(moduleSelect.value, departmentTypeSelect.value);
            } else {
                approvalLevelsSection.classList.add('d-none');
                approvalLevels.innerHTML = '';
            }
        }
        
        moduleSelect.addEventListener('change', checkSelections);
        departmentTypeSelect.addEventListener('change', checkSelections);
        
        // Load existing workflow if available
        function loadExistingWorkflow(module, departmentType) {
            fetch(`<?php echo e(route('settings.workflow.getData')); ?>?module=${module}&department_type=${departmentType}`)
                .then(response => response.json())
                .then(data => {
                    approvalLevelsSection.classList.remove('d-none');
                    approvalLevels.innerHTML = '';
                    
                    if (data.workflow) {
                        // Populate with existing workflow data
                        const flow = data.workflow.approval_flow;
                        flow.sort((a, b) => a.level - b.level);
                        
                        flow.forEach(level => {
                            addApprovalLevel(level.level, level.user_ids);
                        });
                    } else {
                        // Add an initial empty level
                        addApprovalLevel(1);
                    }
                })
                .catch(error => console.error('Error loading workflow:', error));
        }
        
        // Add a new approval level
        addLevelBtn.addEventListener('click', function() {
            const currentLevels = approvalLevels.querySelectorAll('.approval-level');
            const newLevelNumber = currentLevels.length + 1;
            addApprovalLevel(newLevelNumber);
        });
        
        // Add approval level with optional prefill data
        function addApprovalLevel(levelNumber, selectedUserIds = []) {
            const levelDiv = document.createElement('div');
            levelDiv.className = 'approval-level card mb-3';
            levelDiv.dataset.level = levelNumber;
            
            levelDiv.innerHTML = `
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">Level ${levelNumber}</h6>
                    ${levelNumber > 1 ? '<button type="button" class="btn btn-sm btn-danger remove-level-btn"><i class="las la-trash"></i></button>' : ''}
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label class="form-label">Pilih User yang Dapat Melakukan Approval:</label>
                        <select class="form-control select2 user-select" name="approval_flow[${levelNumber}][user_ids][]" multiple required>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>">
                                    <?php echo e($user->name); ?> <?php echo e($user->employee ? '(' . $user->employee->position . ')' : ''); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="approval_flow[${levelNumber}][level]" value="${levelNumber}">
                    </div>
                </div>
            `;
            
            approvalLevels.appendChild(levelDiv);
            
            // Initialize Select2 for the new dropdown
            const select = levelDiv.querySelector('.select2');
            if($.fn.select2) {
                $(select).select2();
                
                // Preselect users if provided
                if (selectedUserIds && selectedUserIds.length) {
                    $(select).val(selectedUserIds).trigger('change');
                }
            }
            
            // Handle remove level button
            const removeBtn = levelDiv.querySelector('.remove-level-btn');
            if (removeBtn) {
                removeBtn.addEventListener('click', function() {
                    levelDiv.remove();
                    renumberLevels();
                });
            }
        }
        
        // Renumber levels after deletion
        function renumberLevels() {
            const levels = approvalLevels.querySelectorAll('.approval-level');
            levels.forEach((level, index) => {
                const levelNumber = index + 1;
                level.dataset.level = levelNumber;
                level.querySelector('h6').textContent = `Level ${levelNumber}`;
                
                // Update input names and values
                const userSelect = level.querySelector('.user-select');
                userSelect.name = `approval_flow[${levelNumber}][user_ids][]`;
                
                const levelInput = level.querySelector('input[type="hidden"]');
                levelInput.name = `approval_flow[${levelNumber}][level]`;
                levelInput.value = levelNumber;
            });
        }
        
        // View workflow details
        document.querySelectorAll('.view-workflow-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const module = this.dataset.module;
                const departmentType = this.dataset.departmentType;
                
                fetch(`<?php echo e(route('settings.workflow.getData')); ?>?module=${module}&department_type=${departmentType}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.workflow) {
                            displayWorkflowDetails(data.workflow);
                        }
                    })
                    .catch(error => console.error('Error loading workflow details:', error));
            });
        });
        
        // Display workflow details in modal
        function displayWorkflowDetails(workflow) {
            const detailContent = document.getElementById('workflowDetailContent');
            const flow = workflow.approval_flow.sort((a, b) => a.level - b.level);
            
            // Set modal title
            document.getElementById('workflowDetailModalLabel').textContent = 
                `Detail Workflow: ${workflow.name}`;
            
            // Build the content
            let html = `
                <div class="row mb-3">
                    <div class="col-md-6">
                        <strong>Modul:</strong> ${ucfirst(workflow.module)}
                    </div>
                    <div class="col-md-6">
                        <strong>Tipe Departemen:</strong> ${ucfirst(workflow.department_type)}
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="100">Level</th>
                                <th>Approver</th>
                            </tr>
                        </thead>
                        <tbody>
            `;
            
            // Add each level to the table
            flow.forEach(level => {
                html += `
                    <tr>
                        <td class="text-center">${level.level}</td>
                        <td>
                            <ul class="list-unstyled mb-0">
                `;
                
                // Fetch user details
                if (level.user_ids && level.user_ids.length) {
                    // Use an AJAX call to get user details by IDs if needed
                    // For this example, we'll just use a static approach with the users variable
                    const userIds = level.user_ids;
                    const usersList = [];
                    
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        if (userIds.includes(<?php echo e($user->id); ?>)) {
                            usersList.push('<?php echo e($user->name); ?> <?php echo e($user->employee ? "(" . $user->employee->position . ")" : ""); ?>');
                        }
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    usersList.forEach(user => {
                        html += `<li>${user}</li>`;
                    });
                } else {
                    html += `<li>Tidak ada approver yang ditentukan</li>`;
                }
                
                html += `
                            </ul>
                        </td>
                    </tr>
                `;
            });
            
            html += `
                        </tbody>
                    </table>
                </div>
            `;
            
            detailContent.innerHTML = html;
            
            // Show the modal
            const modal = new bootstrap.Modal(document.getElementById('workflowDetailModal'));
            modal.show();
        }
        
        // Helper function to capitalize first letter
        function ucfirst(string) {
            return string.charAt(0).toUpperCase() + string.slice(1);
        }
    });
</script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/settings/workflow.blade.php ENDPATH**/ ?>