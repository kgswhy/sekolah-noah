

<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Klaim Berobat Jalan</h3>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                <li class="breadcrumb-item active">Klaim Berobat Jalan</li>
            </ol>
        </nav>
    </div>
    <div class="ms-auto">
        <a href="/klaim-berobat/create" class="btn btn-primary">Ajukan Klaim</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <table class="table table-bordered" id="claimTable">
            <thead>
                <tr>
                    <th>Nama Pegawai</th>
                    <th>Nomor Induk</th>
                    <th>Unit</th>
                    <th>Divisi</th>
                    <th>Nama Pasien</th>
                    <th>Hubungan</th>
                    <th>Total Klaim</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Siti Amalia</td>
                    <td>EMP102</td>
                    <td>Kantor Pusat</td>
                    <td>HRD</td>
                    <td>Putri Amalia</td>
                    <td>Anak</td>
                    <td>Rp 450.000</td>
                    <td>
                        <a href="#" class="btn btn-warning btn-sm">Edit</a>
                        <a href="#" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?');">Delete</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function () {
        $('#claimTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/user/Documents/Kia/sekolah-noah/resources/views/pages/klaim-berobat/index.blade.php ENDPATH**/ ?>