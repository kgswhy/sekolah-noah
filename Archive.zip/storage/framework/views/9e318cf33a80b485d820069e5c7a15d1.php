<!-- resources/views/pages/salary-component/index.blade.php -->



<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Komponen Gaji: <?php echo e($employee->name); ?></h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item" aria-current="page">HRD</li>
                    <li class="breadcrumb-item" aria-current="page"><a href="/employee">Data Karyawan</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Komponen Gaji</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="ms-auto">
    <a href="<?php echo e(route('salary-components.create', $employee->id)); ?>" class="btn btn-primary">Tambah Komponen Gaji</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Amount</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $salaryComponents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $component): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($component->title); ?></td>
                                <td><?php echo e($component->description); ?></td>
                                <td>Rp <?php echo e(number_format($component->amount)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('salary-components.edit', [$employee->id, $component->id])); ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="<?php echo e(route('salary-components.destroy', [$employee->id, $component->id])); ?>" onclick="return confirm('Are you sure?')" class="btn btn-danger btn-sm">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-end"><strong>Total Gaji</strong></td>
                            <td><strong>Rp <?php echo e(number_format($salaryComponents->sum('amount'))); ?></strong></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u803666018/domains/mudamudiworks.com/public_html/sekolah-noah/server/resources/views/pages/salary-component/index.blade.php ENDPATH**/ ?>