

<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Data Payroll</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item" aria-current="page">HRD</li>
                    <li class="breadcrumb-item active" aria-current="page">Data Payroll</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="ms-auto">
        <form method="GET" action="/payroll" class="d-flex">
            <input type="month" name="monthyear" class="form-control" value="<?php echo e(request('monthyear')); ?>" required>
            <button type="submit" class="btn btn-primary ms-2">Tampilkan</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <!-- Card untuk Tabel Data Payroll -->
        <div class="card">
            <div class="card-body">
                <table id="payrollTable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tanggal</th>
                            <th>Karyawan</th>
                            <th>Nominal</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Data Payroll akan ditambahkan disini -->
                        <?php $__currentLoopData = $payrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($payroll->id); ?></td>
                                <td><?php echo e($payroll->date); ?></td>
                                <td><?php echo e($payroll->employee->name); ?></td>
                                <td>Rp <?php echo e(number_format($payroll->amount, 0, ',', '.')); ?></td>
                                <td>
                                    <select class="form-control form-control-sm" name="status" onchange="updateStatus(<?php echo e($payroll->id); ?>, this.value)">
                                        <option value="Unpaid" <?php echo e($payroll->status == 'Unpaid' ? 'selected' : ''); ?>>Unpaid</option>
                                        <option value="Paid" <?php echo e($payroll->status == 'Paid' ? 'selected' : ''); ?>>Paid</option>
                                    </select>
                                </td>
                                <td>
                                    <a href="/payroll/slip/<?php echo e($payroll->id); ?>" class="btn btn-info btn-sm" target="_blank">Slip Gaji</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- Tambahkan data lainnya sesuai kebutuhan -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#payrollTable').DataTable();
    });

    // Update status payroll
    function updateStatus(payrollId, status) {
        $.ajax({
            url: '/payroll/update-status',
            method: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                payroll_id: payrollId,
                status: status
            },
            success: function(response) {
                alert('Status berhasil diperbarui!');
            },
            error: function(xhr, status, error) {
                alert('Terjadi kesalahan saat memperbarui status!');
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u803666018/domains/mudamudiworks.com/public_html/sekolah-noah/server/resources/views/pages/payroll/index.blade.php ENDPATH**/ ?>