<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Daftar Permintaan ATK</h3>
                        <div class="card-tools">
                            <a href="<?php echo e(route('request-atk.create')); ?>" class="btn btn-primary btn-sm">
                                Tambah Permintaan
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Lengkap</th>
                                        <th>Unit</th>
                                        <th>Divisi</th>
                                        <th>Status Karyawan</th>
                                        <th>Jabatan</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($request->nama_lengkap); ?></td>
                                            <td><?php echo e($request->unit); ?></td>
                                            <td><?php echo e($request->divisi); ?></td>
                                            <td><?php echo e($request->status_karyawan); ?></td>
                                            <td><?php echo e($request->jabatan); ?></td>
                                            <td>
                                                <?php switch($request->status):
                                                    case ('pending'): ?>
                                                        <span class="badge bg-warning">Menunggu Approval</span>
                                                    <?php break; ?>

                                                    <?php case ('approved'): ?>
                                                        <span class="badge bg-success">Disetujui</span>
                                                    <?php break; ?>

                                                    <?php case ('rejected'): ?>
                                                        <span class="badge bg-danger">Ditolak</span>
                                                    <?php break; ?>
                                                <?php endswitch; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?php echo e(route('request-atk.show', $request->id)); ?>"
                                                        class="btn btn-info btn-sm">
                                                        Detail
                                                    </a>

                                                    <?php if($request->status === 'pending' && auth()->user()->role_id === 1): ?>
                                                        <button type="button" class="btn btn-success btn-sm"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#approveModal<?php echo e($request->id); ?>">
                                                            Setuju
                                                        </button>
                                                        <button type="button" class="btn btn-danger btn-sm"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#rejectModal<?php echo e($request->id); ?>">
                                                            Tolak
                                                        </button>
                                                    <?php endif; ?>
                                                </div>

                                                <!-- Approve Modal -->
                                                <div class="modal fade" id="approveModal<?php echo e($request->id); ?>"
                                                    tabindex="-1">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <form action="<?php echo e(route('request-atk.approve', $request->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Setujui Permintaan ATK</h5>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <p>Apakah Anda yakin ingin menyetujui permintaan ATK
                                                                        ini?</p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit"
                                                                        class="btn btn-success">Setujui</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Reject Modal -->
                                                <div class="modal fade" id="rejectModal<?php echo e($request->id); ?>" tabindex="-1">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <form action="<?php echo e(route('request-atk.reject', $request->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Tolak Permintaan ATK</h5>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="mb-3">
                                                                        <label for="rejected_message"
                                                                            class="form-label">Alasan Penolakan</label>
                                                                        <textarea class="form-control" id="rejected_message" name="rejected_message" required></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit"
                                                                        class="btn btn-danger">Tolak</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="8" class="text-center">Tidak ada data</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/request-atk/index.blade.php ENDPATH**/ ?>