<?php $__env->startSection('header'); ?>
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h3 class="page-title">Peminjaman Peralatan</h3>
            <div class="d-inline-block align-items-center">
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('equipment-loan.index')); ?>"><i class="mdi mdi-home-outline"></i></a></li>
                        <li class="breadcrumb-item" aria-current="page">Peminjaman</li>
                        <li class="breadcrumb-item active" aria-current="page">Buat Permintaan</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="box">
                <div class="box-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('equipment-loan.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <!-- Nama Peralatan -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="equipment_name">Nama Peralatan <span class="text-danger">*</span></label>
                                    <select class="form-control <?php $__errorArgs = ['equipment_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="equipment_name" name="equipment_name" required>
                                        <option value="">Pilih Peralatan</option>
                                        <option value="Laptop" <?php echo e(old('equipment_name') == 'Laptop' ? 'selected' : ''); ?>>Laptop</option>
                                        <option value="Projector" <?php echo e(old('equipment_name') == 'Projector' ? 'selected' : ''); ?>>Projector</option>
                                        <option value="Camera" <?php echo e(old('equipment_name') == 'Camera' ? 'selected' : ''); ?>>Camera</option>
                                        <option value="Speaker" <?php echo e(old('equipment_name') == 'Speaker' ? 'selected' : ''); ?>>Speaker</option>
                                        <option value="Microphone" <?php echo e(old('equipment_name') == 'Microphone' ? 'selected' : ''); ?>>Microphone</option>
                                    </select>
                                    <?php $__errorArgs = ['equipment_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Nama User -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="user_name">Nama User</label>
                                    <input type="text" class="form-control" id="user_name" value="<?php echo e(Auth::user()->employee->full_name); ?>" readonly>
                                </div>
                            </div>

                            <!-- Unit -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="unit">Unit <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="unit" name="unit" value="<?php echo e(old('unit', Auth::user()->employee->unit)); ?>" required>
                                    <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Divisi -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="division">Divisi <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="division" name="division" value="<?php echo e(old('division', Auth::user()->employee->division)); ?>" required>
                                    <?php $__errorArgs = ['division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Tanggal Pinjam -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="loan_date">Tanggal Pinjam <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control <?php $__errorArgs = ['loan_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="loan_date" name="loan_date" value="<?php echo e(old('loan_date')); ?>" required>
                                    <?php $__errorArgs = ['loan_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Tanggal Kembali -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="return_date">Tanggal Kembali <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control <?php $__errorArgs = ['return_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="return_date" name="return_date" value="<?php echo e(old('return_date')); ?>" required>
                                    <?php $__errorArgs = ['return_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Tujuan Peminjaman -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="purpose">Tujuan Peminjaman <span class="text-danger">*</span></label>
                                    <textarea class="form-control <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="purpose" name="purpose" rows="4" required><?php echo e(old('purpose')); ?></textarea>
                                    <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Submit Button -->
                            <div class="col-md-12 mt-3">
                                <button type="submit" class="btn btn-primary">Kirim Permintaan</button>
                                <a href="<?php echo e(route('equipment-loan.index')); ?>" class="btn btn-secondary">Kembali</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Set minimum date for loan_date to today
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('loan_date').min = today;

            // Update return_date minimum when loan_date changes
            document.getElementById('loan_date').addEventListener('change', function() {
                document.getElementById('return_date').min = this.value;
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/equipment-loan/create.blade.php ENDPATH**/ ?>