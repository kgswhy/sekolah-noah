<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Edit Surat Tugas</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('surat-tugas.index')); ?>">Surat Tugas</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Surat Tugas</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('surat-tugas.update', $suratTugas->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <h5>Data Pegawai</h5>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label>Nama Lengkap</label>
                            <input type="text" class="form-control" value="<?php echo e($suratTugas->employee->full_name ?? '-'); ?>" readonly>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label>Nomor Induk Karyawan</label>
                            <input type="text" class="form-control" value="<?php echo e($suratTugas->employee->nik ?? '-'); ?>" readonly>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label>Unit</label>
                            <input type="text" class="form-control" value="<?php echo e($suratTugas->employee->unit ?? '-'); ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Divisi</label>
                            <input type="text" class="form-control" value="<?php echo e($suratTugas->employee->division ?? '-'); ?>" readonly>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>Status Karyawan</label>
                            <input type="text" class="form-control" value="<?php echo e($suratTugas->employee->employee_status ?? '-'); ?>" readonly>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label>Jabatan</label>
                            <input type="text" class="form-control" value="<?php echo e($suratTugas->employee->position ?? '-'); ?>" readonly>
                        </div>
                    </div>

                    <hr>
                    <h5>Data Surat Tugas</h5>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="judul_tugas">Judul Tugas</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['judul_tugas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="judul_tugas" name="judul_tugas" value="<?php echo e(old('judul_tugas', $suratTugas->judul_tugas)); ?>" required>
                            <?php $__errorArgs = ['judul_tugas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="lokasi_tugas">Lokasi Tugas</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['lokasi_tugas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lokasi_tugas" name="lokasi_tugas" value="<?php echo e(old('lokasi_tugas', $suratTugas->lokasi_tugas)); ?>" required>
                            <?php $__errorArgs = ['lokasi_tugas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="tanggal_mulai">Tanggal Mulai</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_mulai" name="tanggal_mulai" value="<?php echo e(old('tanggal_mulai', $suratTugas->tanggal_mulai->format('Y-m-d'))); ?>" required>
                            <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="tanggal_selesai">Tanggal Selesai</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['tanggal_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_selesai" name="tanggal_selesai" value="<?php echo e(old('tanggal_selesai', $suratTugas->tanggal_selesai ? $suratTugas->tanggal_selesai->format('Y-m-d') : '')); ?>">
                            <small class="text-muted">Isi jika berbeda dengan tanggal mulai</small>
                            <?php $__errorArgs = ['tanggal_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="deskripsi_tugas">Deskripsi Tugas</label>
                            <textarea class="form-control <?php $__errorArgs = ['deskripsi_tugas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="deskripsi_tugas" name="deskripsi_tugas" rows="3" required><?php echo e(old('deskripsi_tugas', $suratTugas->deskripsi_tugas)); ?></textarea>
                            <?php $__errorArgs = ['deskripsi_tugas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="tujuan_tugas">Tujuan Tugas</label>
                            <textarea class="form-control <?php $__errorArgs = ['tujuan_tugas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tujuan_tugas" name="tujuan_tugas" rows="3" required><?php echo e(old('tujuan_tugas', $suratTugas->tujuan_tugas)); ?></textarea>
                            <?php $__errorArgs = ['tujuan_tugas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="keterangan">Keterangan Tambahan</label>
                            <textarea class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="keterangan" name="keterangan" rows="3"><?php echo e(old('keterangan', $suratTugas->keterangan)); ?></textarea>
                            <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <hr>
                    <h5>Dokumen Pendukung</h5>
                    <div class="mb-3">
                        <label for="dokumen_pendukung">Upload Dokumen</label>
                        <?php if($suratTugas->dokumen_pendukung): ?>
                            <div class="mb-2">
                                <p class="mb-1">Dokumen saat ini:</p>
                                <a href="<?php echo e(route('surat-tugas.preview', $suratTugas->id)); ?>" target="_blank" class="btn btn-sm btn-info">
                                    <i class="las la-eye"></i> Preview Dokumen
                                </a>
                            </div>
                        <?php endif; ?>
                        <input type="file" class="form-control <?php $__errorArgs = ['dokumen_pendukung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dokumen_pendukung" name="dokumen_pendukung">
                        <small class="text-muted">Biarkan kosong jika tidak ingin mengubah dokumen</small>
                        <?php $__errorArgs = ['dokumen_pendukung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Perbarui</button>
                        <a href="<?php echo e(route('surat-tugas.index')); ?>" class="btn btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/surat-tugas/edit.blade.php ENDPATH**/ ?>