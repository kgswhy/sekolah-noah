

<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Form Pengajuan Pinjaman</h3>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('pinjaman.index')); ?>">Pinjaman & Cicilan</a></li>
                <li class="breadcrumb-item active">Pengajuan Baru</li>
            </ol>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="card-title">Form Pengajuan Pinjaman</h5>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form action="<?php echo e(route('pinjaman.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            <div class="mb-3 row">
                <label class="col-form-label col-md-3">Nama Karyawan</label>
                <div class="col-md-9">
                    <input type="text" class="form-control" value="<?php echo e($employee->full_name); ?>" readonly>
                </div>
            </div>
            
            <div class="mb-3 row">
                <label class="col-form-label col-md-3">Nomor Induk</label>
                <div class="col-md-9">
                    <input type="text" class="form-control" value="<?php echo e($employee->employee_number); ?>" readonly>
                </div>
            </div>
            
            <div class="mb-3 row">
                <label for="jumlah_pinjaman" class="col-form-label col-md-3">Jumlah Pinjaman</label>
                <div class="col-md-9">
                    <div class="input-group">
                        <span class="input-group-text">Rp</span>
                        <input type="number" class="form-control" id="jumlah_pinjaman" name="jumlah_pinjaman" value="<?php echo e(old('jumlah_pinjaman')); ?>" required>
                    </div>
                </div>
            </div>
            
            <div class="mb-3 row">
                <label for="tujuan_pinjaman" class="col-form-label col-md-3">Tujuan Pinjaman</label>
                <div class="col-md-9">
                    <input type="text" class="form-control" id="tujuan_pinjaman" name="tujuan_pinjaman" value="<?php echo e(old('tujuan_pinjaman')); ?>" required>
                </div>
            </div>
            
            <div class="mb-3 row">
                <label for="jangka_waktu" class="col-form-label col-md-3">Jangka Waktu (bulan)</label>
                <div class="col-md-9">
                    <input type="number" class="form-control" id="jangka_waktu" name="jangka_waktu" min="1" max="36" value="<?php echo e(old('jangka_waktu')); ?>" required>
                    <small class="text-muted">Maksimal 36 bulan (3 tahun)</small>
                </div>
            </div>
            
            <div class="mb-3 row">
                <label for="tanggal_pengajuan" class="col-form-label col-md-3">Tanggal Pengajuan</label>
                <div class="col-md-9">
                    <input type="date" class="form-control" id="tanggal_pengajuan" name="tanggal_pengajuan" value="<?php echo e(old('tanggal_pengajuan') ?? date('Y-m-d')); ?>" required>
                </div>
            </div>
            
            <div class="mb-3 row">
                <label for="dokumen_pendukung" class="col-form-label col-md-3">Dokumen Pendukung</label>
                <div class="col-md-9">
                    <input type="file" class="form-control" id="dokumen_pendukung" name="dokumen_pendukung">
                    <small class="text-muted">Format: PDF, JPG, JPEG, PNG (Maks: 2MB)</small>
                </div>
            </div>
            
            <div class="mb-3 row">
                <div class="col-md-9 offset-md-3">
                    <div id="cicilan_preview" class="alert alert-info d-none">
                        <h6 class="alert-heading">Simulasi Cicilan:</h6>
                        <div>Jumlah Pinjaman: <span id="preview_pinjaman">Rp 0</span></div>
                        <div>Jangka Waktu: <span id="preview_waktu">0</span> bulan</div>
                        <div>Cicilan per Bulan: <span id="preview_cicilan">Rp 0</span></div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-9 offset-md-3">
                    <button type="submit" class="btn btn-primary">Ajukan Pinjaman</button>
                    <a href="<?php echo e(route('pinjaman.index')); ?>" class="btn btn-secondary ms-2">Batal</a>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const jumlahInput = document.getElementById('jumlah_pinjaman');
        const jangkaInput = document.getElementById('jangka_waktu');
        const previewDiv = document.getElementById('cicilan_preview');
        const previewPinjaman = document.getElementById('preview_pinjaman');
        const previewWaktu = document.getElementById('preview_waktu');
        const previewCicilan = document.getElementById('preview_cicilan');
        
        function updatePreview() {
            const jumlah = parseFloat(jumlahInput.value) || 0;
            const jangka = parseFloat(jangkaInput.value) || 0;
            
            if (jumlah > 0 && jangka > 0) {
                const cicilan = jumlah / jangka;
                
                previewPinjaman.textContent = 'Rp ' + jumlah.toLocaleString('id-ID');
                previewWaktu.textContent = jangka;
                previewCicilan.textContent = 'Rp ' + cicilan.toLocaleString('id-ID', {maximumFractionDigits: 2});
                
                previewDiv.classList.remove('d-none');
            } else {
                previewDiv.classList.add('d-none');
            }
        }
        
        jumlahInput.addEventListener('input', updatePreview);
        jangkaInput.addEventListener('input', updatePreview);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/pinjaman-cicilan/create.blade.php ENDPATH**/ ?>