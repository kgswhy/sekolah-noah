<?php $__env->startSection('header'); ?>
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h3 class="page-title">Permintaan Perbaikan</h3>
            <div class="d-inline-block align-items-center">
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
                        <li class="breadcrumb-item" aria-current="page">IT</li>
                        <li class="breadcrumb-item active" aria-current="page">Permintaan Perbaikan</li>
                    </ol>
                </nav>
            </div>
        </div>
        <div>
            <a href="/it/fixing-request/create" class="btn btn-primary">Tambah Permintaan</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="box">
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table mb-0" id="studentTable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Tanggal Pengajuan</th>
                                    <th scope="col">Kategori Perangkat IT</th>
                                    <th scope="col">User</th>
                                    <th scope="col">Unit</th>
                                    <th scope="col">Rincian Kerusakan</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Keterangan</th>
                                    <th scope="col">Approval</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $fixing_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($request->created_at->format('d-m-Y')); ?></td>
                                        <td><?php echo e($request->device_category); ?></td>
                                        <td><?php echo e($request->user->name); ?></td>
                                        <td><?php echo e($request->unit); ?></td>
                                        <td><?php echo e($request->damage_details); ?></td>
                                        <td>
                                            <?php if($request->status == 'pending'): ?>
                                                <span class="badge bg-warning">Menunggu</span>
                                            <?php elseif($request->status == 'approved'): ?>
                                                <span class="badge bg-success">Disetujui</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Ditolak</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($request->rejected_message ?? '-'); ?></td>
                                        <td>
                                            <?php if($request->status === 'pending'): ?>
                                                <a href="<?php echo e(route('fixing-request.approve', $request->id)); ?>" class="btn btn-success btn-sm">Terima</a>

                                                <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#rejectModal-<?php echo e($request->id); ?>">
                                                    Tolak
                                                </button>

                                                <div class="modal fade" id="rejectModal-<?php echo e($request->id); ?>" tabindex="-1" aria-labelledby="rejectModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <form action="<?php echo e(route('fixing-request.reject', $request->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Tolak Permintaan Perbaikan</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="mb-3">
                                                                        <label for="rejected_message" class="form-label">Alasan Penolakan</label>
                                                                        <textarea name="rejected_message" class="form-control" required></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="submit" class="btn btn-danger">Tolak</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="#" class="btn btn-info btn-sm">Detail</a>
                                            <a href="#" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#studentTable').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u803666018/domains/mudamudiworks.com/public_html/sekolah-noah/server/resources/views/pages/fixing-request/index.blade.php ENDPATH**/ ?>