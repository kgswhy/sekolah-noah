<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Request Kurir / Mobil Operasional</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Operasional</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="ms-auto">
        <a href="<?php echo e(route('operasional.create')); ?>" class="btn btn-primary">Tambah Request</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <!-- Tabel Request Kurir -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Request Kurir</h5>
                <table id="kurirTable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Unit</th>
                            <th>Divisi</th>
                            <th>Request By</th>
                            <th>Jenis</th>
                            <th>Tanggal</th>
                            <th>Jam</th>
                            <th>Tujuan</th>
                            <th>Keperluan</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $kurirRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($r->unit); ?></td>
                            <td><?php echo e($r->divisi); ?></td>
                            <td><?php echo e($r->request_by); ?></td>
                            <td><?php echo e($r->jenis); ?></td>
                            <td><?php echo e($r->tanggal); ?></td>
                            <td><?php echo e($r->dari_jam); ?> - <?php echo e($r->sampai_jam); ?></td>
                            <td><?php echo e($r->tujuan); ?></td>
                            <td><?php echo e($r->keperluan); ?></td>
                            <td><?php echo e($r->keterangan); ?></td>
                            <td>
                                <a href="<?php echo e(route('operasional.edit', $r->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="<?php echo e(route('operasional.destroy', $r->id)); ?>"
                                   onclick="return confirm('Yakin ingin menghapus data ini?')"
                                   class="btn btn-danger btn-sm">Hapus</a>

                                   
                                   <button type="button" class="btn btn-success btn-sm"
                                                            
                                   >Setuju
                               </button>
                               <button type="button" class="btn btn-danger btn-sm"
                                   >
                                   Tolak
                               </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Tabel Request Mobil -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Request Mobil</h5>
                <table id="mobilTable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Unit</th>
                            <th>Divisi</th>
                            <th>Request By</th>
                            <th>Jenis</th>
                            <th>Tanggal</th>
                            <th>Jam</th>
                            <th>Tujuan</th>
                            <th>Keperluan</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $mobilRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($r->unit); ?></td>
                            <td><?php echo e($r->divisi); ?></td>
                            <td><?php echo e($r->request_by); ?></td>
                            <td><?php echo e($r->jenis); ?></td>
                            <td><?php echo e($r->tanggal); ?></td>
                            <td><?php echo e($r->dari_jam); ?> - <?php echo e($r->sampai_jam); ?></td>
                            <td><?php echo e($r->tujuan); ?></td>
                            <td><?php echo e($r->keperluan); ?></td>
                            <td><?php echo e($r->keterangan); ?></td>
                            <td>
                                <a href="<?php echo e(route('operasional.edit', $r->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="<?php echo e(route('operasional.destroy', $r->id)); ?>"
                                   onclick="return confirm('Yakin ingin menghapus data ini?')"
                                   class="btn btn-danger btn-sm">Hapus</a>
                                    
                                   <button type="button" class="btn btn-success btn-sm"
                                                            
                                   >Setuju
                               </button>
                               <button type="button" class="btn btn-danger btn-sm"
                                   >
                                   Tolak
                               </button>
                                   
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function () {
        $('#kurirTable').DataTable();
        $('#mobilTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/operasional/kurir-mobil/index.blade.php ENDPATH**/ ?>