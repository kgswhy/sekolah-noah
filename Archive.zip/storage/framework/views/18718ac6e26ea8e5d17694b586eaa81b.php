

<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Pendaftaran Siswa</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Pendaftaran</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="ms-auto">
        <a href="<?php echo e(route('admission.create')); ?>" class="btn btn-primary">Tambah Pendaftaran</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <table id="regTable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Tujuan Kelas</th>
                            <th>Asal Sekolah</th>
                            <th>Status</th>
                            <th>Pembayaran</th>
                            <th>Observasi</th>
                            <th>Pengumuman</th>
                            <th>ID Card</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($r->nama_siswa); ?></td>
                            <td><?php echo e($r->tujuan_kelas); ?></td>
                            <td><?php echo e($r->asal_sekolah); ?></td>
                            <td><?php echo e($r->status); ?></td>
                            <td><?php echo e($r->pembayaran ? '✔️' : '❌'); ?></td>
                            <td><?php echo e($r->observasi ? '✔️' : '❌'); ?></td>
                            <td><?php echo e($r->pengumuman ? '✔️' : '❌'); ?></td>
                            <td><?php echo e($r->id_card ? '✔️' : '❌'); ?></td>
                            <td>
                                <a href="<?php echo e(route('admission.edit', $r->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="<?php echo e(route('admission.destroy', $r->id)); ?>"
                                    onclick="return confirm('Yakin ingin menghapus data ini?')"
                                    class="btn btn-danger btn-sm">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function () {
        $('#regTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/user/Documents/Kia/sekolah-noah/resources/views/pages/admission/index.blade.php ENDPATH**/ ?>