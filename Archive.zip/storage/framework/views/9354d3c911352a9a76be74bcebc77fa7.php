<?php $__env->startSection('content-header'); ?>
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h3 class="page-title">Detail Request Fotocopy</h3>
            <div class="d-inline-block align-items-center">
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                        <li class="breadcrumb-item">Request</li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('request-fotocopy.index')); ?>">Fotocopy</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Detail</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Informasi Request</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="200">Nama Lengkap</th>
                                    <td><?php echo e($request->nama_lengkap); ?></td>
                                </tr>
                                <tr>
                                    <th>Unit</th>
                                    <td><?php echo e($request->unit); ?></td>
                                </tr>
                                <tr>
                                    <th>Divisi</th>
                                    <td><?php echo e($request->divisi); ?></td>
                                </tr>
                                <tr>
                                    <th>Kegiatan</th>
                                    <td><?php echo e($request->kegiatan); ?></td>
                                </tr>
                                <tr>
                                    <th>Tanggal Penggunaan</th>
                                    <td><?php echo e($request->tanggal_penggunaan); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">Status Approval</h5>
                                </div>
                                <div class="card-body">
                                    <?php
                                        $totalApprovers = \App\Models\Approver::where('module', 'fotocopy')
                                            ->where('active', true)
                                            ->where('department_type', $request->divisi === 'Akademik' ? 'akademik' : 'non-akademik')
                                            ->count();
                                        $currentLevel = $request->current_approval_level;
                                        $finalStatus = $request->final_status;
                                        $approvalHistory = json_decode($request->approval_history, true) ?? [];
                                    ?>

                                    <div class="mb-4">
                                        <?php if($finalStatus === 'approved'): ?>
                                            <div class="alert alert-success">
                                                <i class="fa fa-check-circle"></i> Request telah disetujui
                                            </div>
                                        <?php elseif($finalStatus === 'rejected'): ?>
                                            <div class="alert alert-danger">
                                                <i class="fa fa-times-circle"></i> Request ditolak
                                            </div>
                                        <?php else: ?>
                                            <div class="alert alert-info">
                                                <i class="fa fa-clock"></i> Menunggu approval level <?php echo e($currentLevel); ?> dari <?php echo e($totalApprovers); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <h6 class="mb-3">Riwayat Approval</h6>
                                    <div class="timeline">
                                        <?php $__currentLoopData = $approvalHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="timeline-item">
                                                <div class="timeline-point">
                                                    <?php if($history['status'] === 'approved'): ?>
                                                        <i class="fa fa-check text-success"></i>
                                                    <?php elseif($history['status'] === 'rejected'): ?>
                                                        <i class="fa fa-times text-danger"></i>
                                                    <?php else: ?>
                                                        <i class="fa fa-clock text-warning"></i>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="timeline-content">
                                                    <h6 class="mb-1">Level <?php echo e($history['level']); ?></h6>
                                                    <p class="mb-0">
                                                        <strong><?php echo e($history['approver_name']); ?></strong>
                                                        <?php if($history['status'] === 'approved'): ?>
                                                            menyetujui request
                                                        <?php elseif($history['status'] === 'rejected'): ?>
                                                            menolak request
                                                            <?php if(isset($history['note'])): ?>
                                                                <br>
                                                                <small class="text-danger"><?php echo e($history['note']); ?></small>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            belum memberikan approval
                                                        <?php endif; ?>
                                                    </p>
                                                    <small class="text-muted">
                                                        <?php echo e(\Carbon\Carbon::parse($history['timestamp'])->format('d M Y H:i')); ?>

                                                    </small>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('request-fotocopy.index')); ?>" class="btn btn-secondary">
                        <i class="fa fa-arrow-left"></i> Kembali
                    </a>
                    <?php if($request->final_status !== 'approved' && $request->final_status !== 'rejected'): ?>
                        <a href="<?php echo e(route('request-fotocopy.edit', $request->id)); ?>" class="btn btn-warning">
                            <i class="fa fa-edit"></i> Edit
                        </a>
                        <form action="<?php echo e(route('request-fotocopy.destroy', $request->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus request ini?')">
                                <i class="fa fa-trash"></i> Hapus
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.timeline {
    position: relative;
    padding: 20px 0;
}

.timeline-item {
    position: relative;
    padding-left: 40px;
    margin-bottom: 20px;
}

.timeline-point {
    position: absolute;
    left: 0;
    top: 0;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    background: #f8f9fa;
    display: flex;
    align-items: center;
    justify-content: center;
}

.timeline-content {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 4px;
}
</style>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/request-fotocopy/show.blade.php ENDPATH**/ ?>