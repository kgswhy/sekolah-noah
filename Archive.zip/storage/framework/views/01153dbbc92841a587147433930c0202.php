

<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Edit Karyawan</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item" aria-current="page">HRD</li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Karyawan</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <!-- Card untuk Form Edit Karyawan -->
        <div class="card">
            <div class="card-body">
                <form action="/employee/edit/<?php echo e($employee->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" name="full_name" value="<?php echo e($employee->full_name); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor Induk Karyawan</label>
                            <input type="text" class="form-control" name="employee_number" value="<?php echo e($employee->employee_number); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Unit</label>
                            <input type="text" class="form-control" name="unit" value="<?php echo e($employee->unit); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Divisi</label>
                            <input type="text" class="form-control" name="division" value="<?php echo e($employee->division); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Jabatan</label>
                            <input type="text" class="form-control" name="position" value="<?php echo e($employee->position); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status Karyawan</label>
                            <input type="text" class="form-control" name="employment_status" value="<?php echo e($employee->employment_status); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Jenis Kelamin</label>
                            <select name="gender" class="form-control">
                                <option value="Laki-laki" <?php echo e($employee->gender == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                                <option value="Perempuan" <?php echo e($employee->gender == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Golongan Darah</label>
                            <input type="text" class="form-control" name="blood_type" value="<?php echo e($employee->blood_type); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tempat Lahir</label>
                            <input type="text" class="form-control" name="birth_place" value="<?php echo e($employee->birth_place); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Lahir</label>
                            <input type="date" class="form-control" name="birth_date" value="<?php echo e($employee->birth_date); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">No. BPJS Ketenagakerjaan</label>
                            <input type="text" class="form-control" name="bpjs_ketenagakerjaan_number" value="<?php echo e($employee->bpjs_ketenagakerjaan_number); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">No. BPJS Kesehatan</label>
                            <input type="text" class="form-control" name="bpjs_kesehatan_number" value="<?php echo e($employee->bpjs_kesehatan_number); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">NIK</label>
                            <input type="text" class="form-control" name="nik" value="<?php echo e($employee->nik); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">No. Kartu Keluarga</label>
                            <input type="text" class="form-control" name="kk_number" value="<?php echo e($employee->kk_number); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Agama</label>
                            <input type="text" class="form-control" name="religion" value="<?php echo e($employee->religion); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Pendidikan Terakhir</label>
                            <input type="text" class="form-control" name="last_education" value="<?php echo e($employee->last_education); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Alamat KTP</label>
                            <input type="text" class="form-control" name="ktp_address" value="<?php echo e($employee->ktp_address); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Alamat Domisili</label>
                            <input type="text" class="form-control" name="domicile_address" value="<?php echo e($employee->domicile_address); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor Telepon</label>
                            <input type="text" class="form-control" name="phone_number" value="<?php echo e($employee->phone_number); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">NPWP</label>
                            <input type="text" class="form-control" name="npwp_number" value="<?php echo e($employee->npwp_number); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email Sekolah</label>
                            <input type="email" class="form-control" name="school_email" value="<?php echo e($employee->school_email); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email Lainnya</label>
                            <input type="email" class="form-control" name="other_email" value="<?php echo e($employee->other_email); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status Perkawinan</label>
                            <input type="text" class="form-control" name="marital_status" value="<?php echo e($employee->marital_status); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status Pegawai</label>
                            <select name="employee_status" class="form-control">
                                <option value="aktif" <?php echo e($employee->employee_status == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                                <option value="tidak aktif" <?php echo e($employee->employee_status == 'tidak aktif' ? 'selected' : ''); ?>>Tidak Aktif</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Masuk</label>
                            <input type="date" class="form-control" name="entry_date" value="<?php echo e($employee->entry_date); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Keluar</label>
                            <input type="date" class="form-control" name="exit_date" value="<?php echo e($employee->exit_date); ?>">
                        </div>
                    </div>
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        <a href="<?php echo e(route('employee.index')); ?>" class="btn btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u803666018/domains/mudamudiworks.com/public_html/sekolah-noah/server/resources/views/pages/employee/edit.blade.php ENDPATH**/ ?>