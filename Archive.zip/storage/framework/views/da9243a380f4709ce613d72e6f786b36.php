

<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Ajukan Permintaan Slip Gaji / Surat Keterangan Kerja</h3>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('slip-gaji-skk.index')); ?>">Permintaan Slip Gaji / SKK</a></li>
                <li class="breadcrumb-item active">Ajukan Permintaan</li>
            </ol>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <form action="<?php echo e(route('slip-gaji-skk.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="employee_id" value="<?php echo e($employee->id); ?>">
            
            <h5 class="mb-4">Data Pegawai</h5>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" value="<?php echo e($employee->full_name); ?>" readonly>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Nomor Induk Karyawan</label>
                    <input type="text" class="form-control" value="<?php echo e($employee->employee_number); ?>" readonly>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Unit</label>
                    <input type="text" class="form-control" value="<?php echo e($employee->unit); ?>" readonly>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Divisi</label>
                    <input type="text" class="form-control" value="<?php echo e($employee->division); ?>" readonly>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Status Karyawan</label>
                    <input type="text" class="form-control" value="<?php echo e($employee->employee_status); ?>" readonly>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Jabatan</label>
                    <input type="text" class="form-control" value="<?php echo e($employee->position); ?>" readonly>
                </div>
            </div>

            <hr>
            <h5 class="mb-4">Data Permintaan</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Jenis Permintaan <span class="text-danger">*</span></label>
                    <select class="form-select" name="jenis_permintaan" required>
                        <option value="" selected disabled>Pilih Jenis Permintaan</option>
                        <option value="Slip Gaji" <?php echo e(old('jenis_permintaan') == 'Slip Gaji' ? 'selected' : ''); ?>>Slip Gaji</option>
                        <option value="Surat Keterangan Kerja" <?php echo e(old('jenis_permintaan') == 'Surat Keterangan Kerja' ? 'selected' : ''); ?>>Surat Keterangan Kerja</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Bulan/Tahun <span class="text-danger">*</span></label>
                    <input type="month" class="form-control" name="bulan_tahun" required value="<?php echo e(old('bulan_tahun')); ?>">
                    <div class="form-text text-muted">
                        Format: MM/YYYY (contoh: 01/2023 untuk Januari 2023)
                    </div>
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Keterangan / Tujuan <span class="text-danger">*</span></label>
                    <textarea class="form-control" name="keterangan" rows="3" required><?php echo e(old('keterangan')); ?></textarea>
                </div>
                <div class="col-md-12 mb-4">
                    <label class="form-label">Dokumen Pendukung</label>
                    <input type="file" class="form-control" name="dokumen_pendukung" accept=".pdf,.jpg,.jpeg,.png">
                    <div class="form-text text-muted">
                        File yang diterima: PDF, JPG, JPEG, PNG. Maksimal 2MB.
                    </div>
                </div>
            </div>

            <div class="d-flex">
                <button type="submit" class="btn btn-primary me-2">
                    <i class="fas fa-paper-plane"></i> Kirim Permintaan
                </button>
                <a href="<?php echo e(route('slip-gaji-skk.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
    .btn-primary {
        background-color: #6f42c1;
        border-color: #6f42c1;
    }
    .btn-primary:hover, .btn-primary:focus {
        background-color: #5e35b1;
        border-color: #5e35b1;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/slip-gaji-skk/create.blade.php ENDPATH**/ ?>