<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Edit Langkah Persetujuan</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item">Pengaturan</li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('approval.index')); ?>">Alur Persetujuan</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('approval.edit-workflow', $workflow->id)); ?>"><?php echo e($workflow->display_name); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Langkah</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Form Edit Langkah Persetujuan</h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('approval.update-step', ['workflow' => $workflow->id, 'step' => $step->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="row mb-3">
                        <label for="name" class="col-sm-3 col-form-label">Nama Langkah <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" value="<?php echo e(old('name', $step->name)); ?>" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <label for="order" class="col-sm-3 col-form-label">Urutan <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="order" name="order" value="<?php echo e(old('order', $step->order)); ?>" required min="1">
                            <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <small class="form-text text-muted">Urutan langkah dalam alur persetujuan. Langkah dengan urutan lebih kecil akan diproses terlebih dahulu.</small>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <label for="approval_type" class="col-sm-3 col-form-label">Tipe Persetujuan <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <select class="form-select <?php $__errorArgs = ['approval_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="approval_type" name="approval_type" required>
                                <option value="">-- Pilih Tipe Persetujuan --</option>
                                <?php $__currentLoopData = $approvalTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e(old('approval_type', $step->approval_type) == $key ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['approval_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <label for="approvers" class="col-sm-3 col-form-label">Pemberi Persetujuan <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <select class="form-select <?php $__errorArgs = ['approvers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="approvers" name="approvers[]" multiple required>
                                <?php
                                    $currentApprovers = json_decode($step->getAttributes()['approvers'], true) ?? [];
                                    if (!is_array($currentApprovers)) {
                                        $currentApprovers = [];
                                    }
                                    $oldApprovers = old('approvers', []);
                                    if (!is_array($oldApprovers)) {
                                        $oldApprovers = [];
                                    }
                                ?>
                                
                                <?php if($step->approval_type == 'user'): ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>" <?php echo e(in_array($user->id, $oldApprovers) || in_array($user->id, $currentApprovers) ? 'selected' : ''); ?>><?php echo e($user->name); ?> (<?php echo e($user->email); ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php elseif($step->approval_type == 'role'): ?>
                                    <option value="1" <?php echo e(in_array(1, $oldApprovers) || in_array(1, $currentApprovers) ? 'selected' : ''); ?>>Admin</option>
                                    <option value="2" <?php echo e(in_array(2, $oldApprovers) || in_array(2, $currentApprovers) ? 'selected' : ''); ?>>Manager</option>
                                    <option value="3" <?php echo e(in_array(3, $oldApprovers) || in_array(3, $currentApprovers) ? 'selected' : ''); ?>>Supervisor</option>
                                    <option value="4" <?php echo e(in_array(4, $oldApprovers) || in_array(4, $currentApprovers) ? 'selected' : ''); ?>>Staff</option>
                                <?php elseif($step->approval_type == 'department'): ?>
                                    <option value="1" <?php echo e(in_array(1, old('approvers', $currentApprovers)) ? 'selected' : ''); ?>>Admin</option>
                                    <option value="2" <?php echo e(in_array(2, old('approvers', $currentApprovers)) ? 'selected' : ''); ?>>Manager</option>
                                    <option value="3" <?php echo e(in_array(3, old('approvers', $currentApprovers)) ? 'selected' : ''); ?>>Supervisor</option>
                                    <option value="4" <?php echo e(in_array(4, old('approvers', $currentApprovers)) ? 'selected' : ''); ?>>Staff</option>
                                <?php elseif($step->approval_type == 'department'): ?>
                                    <option value="1" <?php echo e(in_array(1, old('approvers', $currentApprovers)) ? 'selected' : ''); ?>>HR Department</option>
                                    <option value="2" <?php echo e(in_array(2, old('approvers', $currentApprovers)) ? 'selected' : ''); ?>>Finance Department</option>
                                    <option value="3" <?php echo e(in_array(3, old('approvers', $currentApprovers)) ? 'selected' : ''); ?>>IT Department</option>
                                    <option value="4" <?php echo e(in_array(4, old('approvers', $currentApprovers)) ? 'selected' : ''); ?>>Operations Department</option>
                                <?php endif; ?>
                            </select>
                            <?php $__errorArgs = ['approvers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <small class="form-text text-muted">Pilih satu atau beberapa pemberi persetujuan. Tekan tombol Ctrl sambil mengklik untuk memilih beberapa.</small>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-sm-9 offset-sm-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="all_must_approve" name="all_must_approve" value="1" <?php echo e(old('all_must_approve', $step->all_must_approve) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="all_must_approve">
                                    Semua Pemberi Persetujuan Harus Menyetujui
                                </label>
                            </div>
                            <small class="form-text text-muted">Jika dicentang, semua pemberi persetujuan harus menyetujui. Jika tidak, cukup satu pemberi persetujuan saja.</small>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-sm-9 offset-sm-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" <?php echo e(old('is_active', $step->is_active) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="is_active">
                                    Aktifkan Langkah Persetujuan
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-sm-9 offset-sm-3">
                            <a href="<?php echo e(route('approval.edit-workflow', $workflow->id)); ?>" class="btn btn-secondary me-2">Kembali</a>
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Handle approval type change
        $('#approval_type').change(function() {
            var type = $(this).val();
            
            // Clear the current options
            $('#approvers').empty();
            
            if (type === 'user') {
                // Populate with users
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                $('#approvers').append('<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> (<?php echo e($user->email); ?>)</option>');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            } else if (type === 'role') {
                // Populate with roles (this is just a placeholder, you'd need to fetch actual roles)
                $('#approvers').append('<option value="1">Admin</option>');
                $('#approvers').append('<option value="2">Manager</option>');
                $('#approvers').append('<option value="3">Supervisor</option>');
                $('#approvers').append('<option value="4">Staff</option>');
            } else if (type === 'department') {
                // Populate with departments (this is just a placeholder, you'd need to fetch actual departments)
                $('#approvers').append('<option value="1">HR Department</option>');
                $('#approvers').append('<option value="2">Finance Department</option>');
                $('#approvers').append('<option value="3">IT Department</option>');
                $('#approvers').append('<option value="4">Operations Department</option>');
            }
        });
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/approvals/edit-step.blade.php ENDPATH**/ ?>