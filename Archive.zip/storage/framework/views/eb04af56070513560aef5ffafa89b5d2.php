<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Pengaturan Alur Persetujuan</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item">Pengaturan</li>
                    <li class="breadcrumb-item active" aria-current="page">Alur Persetujuan</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Daftar Alur Persetujuan</h4>
                <div class="card-tools">
                    <a href="<?php echo e(route('approval.create-workflow')); ?>" class="btn btn-primary">
                        <i class="las la-plus"></i> Tambah Alur Persetujuan Baru
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="workflowTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th width="20%">Modul</th>
                                <th width="20%">Nama</th>
                                <th width="20%">Deskripsi</th>
                                <th width="15%">Status</th>
                                <th width="20%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $workflows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $workflow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($workflow->module_name); ?></td>
                                <td><?php echo e($workflow->display_name); ?></td>
                                <td><?php echo e($workflow->description); ?></td>
                                <td>
                                    <?php if($workflow->is_active): ?>
                                    <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                    <span class="badge bg-danger">Tidak Aktif</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('approval.edit-workflow', $workflow->id)); ?>" class="btn btn-info btn-sm">
                                        <i class="las la-edit"></i> Edit
                                    </a>
                                    <a href="#" class="btn btn-danger btn-sm" 
                                       onclick="event.preventDefault(); if(confirm('Apakah Anda yakin ingin menghapus?')) document.getElementById('delete-workflow-<?php echo e($workflow->id); ?>').submit();">
                                        <i class="las la-trash"></i> Hapus
                                    </a>
                                    <form id="delete-workflow-<?php echo e($workflow->id); ?>" action="<?php echo e(route('approval.delete-workflow', $workflow->id)); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if(count($workflows) == 0): ?>
                            <tr>
                                <td colspan="6" class="text-center">Tidak ada data alur persetujuan</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="card mt-4">
            <div class="card-header">
                <h4 class="card-title">Panduan Pengaturan Alur Persetujuan</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-header">
                                <h5>Cara Membuat Alur Persetujuan</h5>
                            </div>
                            <div class="card-body">
                                <ol>
                                    <li>Klik tombol <strong>Tambah Alur Persetujuan Baru</strong></li>
                                    <li>Pilih modul yang akan dibuatkan alur persetujuan</li>
                                    <li>Isi nama dan deskripsi alur persetujuan</li>
                                    <li>Aktifkan atau nonaktifkan alur persetujuan</li>
                                    <li>Tambahkan langkah-langkah persetujuan yang diperlukan</li>
                                    <li>Tentukan pengguna yang berwenang memberikan persetujuan</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-header">
                                <h5>Contoh Alur Persetujuan</h5>
                            </div>
                            <div class="card-body">
                                <p><strong>Contoh Alur Persetujuan Cuti:</strong></p>
                                <ol>
                                    <li>Persetujuan Kepala Departemen</li>
                                    <li>Persetujuan HRD</li>
                                    <li>Persetujuan Direktur (opsional untuk cuti > 3 hari)</li>
                                </ol>
                                <p class="mt-3"><strong>Contoh Alur Persetujuan Pengajuan Dana:</strong></p>
                                <ol>
                                    <li>Persetujuan Kepala Departemen</li>
                                    <li>Persetujuan Keuangan</li>
                                    <li>Persetujuan Direktur</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function() {
        $('#workflowTable').DataTable({
            "language": {
                "search": "Cari:",
                "lengthMenu": "Tampilkan _MENU_ data per halaman",
                "zeroRecords": "Tidak ada data yang ditemukan",
                "info": "Menampilkan halaman _PAGE_ dari _PAGES_",
                "infoEmpty": "Tidak ada data tersedia",
                "infoFiltered": "(difilter dari _MAX_ total data)",
                "paginate": {
                    "first": "Pertama",
                    "last": "Terakhir",
                    "next": "Selanjutnya",
                    "previous": "Sebelumnya"
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/approvals/index.blade.php ENDPATH**/ ?>