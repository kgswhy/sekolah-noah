<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Edit Data Absensi</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('absence.update', $absence->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <div class="form-group">
                            <label>NIK</label>
                            <input type="text" class="form-control" value="<?php echo e($absence->schedule->employee->nik); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Nama Karyawan</label>
                            <input type="text" class="form-control" value="<?php echo e($absence->schedule->employee->full_name); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Tanggal</label>
                            <input type="text" class="form-control" value="<?php echo e($absence->schedule->date); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Shift</label>
                            <input type="text" class="form-control" value="<?php echo e($absence->schedule->shift->name); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Jam Masuk</label>
                            <input type="datetime-local" class="form-control <?php $__errorArgs = ['clock_in'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="clock_in" value="<?php echo e($absence->clock_in ? Carbon\Carbon::parse($absence->clock_in)->format('Y-m-d\TH:i:s') : ''); ?>">
                            <?php $__errorArgs = ['clock_in'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label>Jam Keluar</label>
                            <input type="datetime-local" class="form-control <?php $__errorArgs = ['clock_out'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                name="clock_out" value="<?php echo e($absence->clock_out ? Carbon\Carbon::parse($absence->clock_out)->format('Y-m-d\TH:i:s') : ''); ?>">
                            <?php $__errorArgs = ['clock_out'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="present" <?php echo e($absence->status == 'present' ? 'selected' : ''); ?>>Hadir</option>
                                <option value="late" <?php echo e($absence->status == 'late' ? 'selected' : ''); ?>>Terlambat</option>
                                <option value="absent" <?php echo e($absence->status == 'absent' ? 'selected' : ''); ?>>Tidak Hadir</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            <a href="<?php echo e(route('absence.index')); ?>" class="btn btn-secondary">Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/absence/edit.blade.php ENDPATH**/ ?>