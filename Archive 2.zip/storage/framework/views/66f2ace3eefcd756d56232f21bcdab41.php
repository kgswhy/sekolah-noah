<?php $__env->startSection('title', 'Daftar Slip Gaji'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex align-items-center">
            <h5 class="mb-0">Payroll Slip Gaji</h5>
            <form action="<?php echo e(route('payroll.generate')); ?>" method="POST" class="d-inline ms-auto">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary" onclick="return confirm('Apakah Anda yakin ingin generate payroll untuk semua karyawan aktif?')">
                    Generate Payroll
                </button>
            </form>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>Jabatan</th>
                            <th>Divisi</th>
                            <th>Periode</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $salarySlips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($slip->employee->employee_number); ?></td>
                            <td><?php echo e($slip->employee->full_name); ?></td>
                            <td><?php echo e($slip->employee->position); ?></td>
                            <td><?php echo e($slip->employee->division); ?></td>
                            <td><?php echo e($slip->date->format('F Y')); ?></td>
                            <td class="text-end fw-bold">
                                Rp <?php echo e(number_format($slip->components->sum('amount'), 0, ',', '.')); ?>

                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($slip->status === 'paid' ? 'success' : 'warning'); ?>">
                                    <?php echo e($slip->status === 'paid' ? 'Dibayar' : 'Belum Dibayar'); ?>

                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('payroll.edit', $slip)); ?>" class="btn btn-sm btn-info">
                                        Edit
                                    </a>
                                    <?php if($slip->status === 'paid'): ?>
                                        <a href="<?php echo e(route('payroll.download', $slip)); ?>" class="btn btn-sm btn-secondary">
                                            Download
                                        </a>
                                    <?php endif; ?>
                                    <form action="<?php echo e(route('payroll.update-status', $slip)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="<?php echo e($slip->status === 'paid' ? 'unpaid' : 'paid'); ?>">
                                        <button type="submit" class="btn btn-sm <?php echo e($slip->status === 'paid' ? 'btn-warning' : 'btn-success'); ?>"
                                            onclick="return confirm('Apakah Anda yakin ingin <?php echo e($slip->status === 'paid' ? 'membatalkan' : 'menandai'); ?> pembayaran slip gaji ini?')">
                                            <?php echo e($slip->status === 'paid' ? 'Batalkan Pembayaran' : 'Tandai Dibayar'); ?>

                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center">Tidak ada data</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                    
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/payroll/index.blade.php ENDPATH**/ ?>