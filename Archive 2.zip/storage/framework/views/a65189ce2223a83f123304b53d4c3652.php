<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Daftar Request Fotocopy</h3>
                        <?php if(auth()->user()->isAdmin() || auth()->user()->isApprover()): ?>
                            <div class="card-tools">
                                <a href="<?php echo e(route('request-fotocopy.create')); ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-plus"></i> Buat Request
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped" id="request-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Nama</th>
                                        <th>NIK</th>
                                        <th>Tanggal</th>
                                        <th>Jumlah Halaman</th>
                                        <th>Departemen</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($request->id); ?></td>
                                            <td><?php echo e($request->nama_lengkap); ?></td>
                                            <td><?php echo e($request->nomor_induk_karyawan); ?></td>
                                            <td><?php echo e($request->tanggal_penggunaan); ?></td>
                                            <td>
                                                <?php
                                                    $jumlahHalaman = json_decode($request->jumlah_halaman);
                                                    $jumlahDiperlukan = json_decode($request->jumlah_diperlukan);
                                                    $total = 0;
                                                    for($i = 0; $i < count($jumlahHalaman); $i++) {
                                                        $total += $jumlahHalaman[$i] * $jumlahDiperlukan[$i];
                                                    }
                                                ?>
                                                <?php echo e($total); ?> halaman
                                            </td>
                                            <td><?php echo e(ucfirst($request->department_type)); ?></td>
                                            <td>
                                                <?php if($request->status === 'pending'): ?>
                                                    <span class="badge badge-warning">Pending</span>
                                                <?php elseif($request->status === 'approved'): ?>
                                                    <span class="badge badge-success">Approved</span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger">Rejected</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detailModal<?php echo e($request->id); ?>">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                    
                                                    <?php if(Auth::user()->isAdmin() || Auth::user()->isApproverFor('fotocopy', $request->current_approval_level, $request->department_type)): ?>
                                                        <?php if($request->status === 'pending'): ?>
                                                            <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#approveModal<?php echo e($request->id); ?>">
                                                                <i class="fas fa-check"></i>
                                                            </button>
                                                            <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#rejectModal<?php echo e($request->id); ?>">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    <?php endif; ?>

                                                    <?php if(Auth::user()->employee && $request->employee_id === Auth::user()->employee->id): ?>
                                                        <?php if($request->status === 'pending'): ?>
                                                            <a href="<?php echo e(route('request-fotocopy.edit', $request->id)); ?>" class="btn btn-warning btn-sm">
                                                                <i class="fas fa-edit"></i>
                                                            </a>
                                                            <form action="<?php echo e(route('request-fotocopy.destroy', $request->id)); ?>" method="POST" class="d-inline">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus request ini?')">
                                                                    <i class="fas fa-trash"></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>

                                                <!-- Detail Modal -->
                                                <div class="modal fade" id="detailModal<?php echo e($request->id); ?>" tabindex="-1" role="dialog">
                                                    <div class="modal-dialog modal-lg" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">Detail Request Fotocopy</h5>
                                                                <button type="button" class="close" data-dismiss="modal">
                                                                    <span>&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <p><strong>Nama:</strong> <?php echo e($request->nama_lengkap); ?></p>
                                                                        <p><strong>NIK:</strong> <?php echo e($request->nomor_induk_karyawan); ?></p>
                                                                        <p><strong>Unit:</strong> <?php echo e($request->unit); ?></p>
                                                                        <p><strong>Divisi:</strong> <?php echo e($request->divisi); ?></p>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <p><strong>Status Karyawan:</strong> <?php echo e($request->status_karyawan); ?></p>
                                                                        <p><strong>Jabatan:</strong> <?php echo e($request->jabatan); ?></p>
                                                                        <p><strong>Kegiatan:</strong> <?php echo e($request->kegiatan); ?></p>
                                                                        <p><strong>Subject:</strong> <?php echo e($request->subject); ?></p>
                                                                    </div>
                                                                </div>
                                                                <div class="row mt-3">
                                                                    <div class="col-12">
                                                                        <h6>Detail Barang</h6>
                                                                        <table class="table table-bordered">
                                                                            <thead>
                                                                                <tr>
                                                                                    <th>Nama Barang</th>
                                                                                    <th>Jumlah Halaman</th>
                                                                                    <th>Jumlah Diperlukan</th>
                                                                                    <th>Keterangan</th>
                                                                                </tr>
                                                                            </thead>
                                                                            <tbody>
                                                                                <?php
                                                                                    $namaBarang = json_decode($request->nama_barang);
                                                                                    $jumlahHalaman = json_decode($request->jumlah_halaman);
                                                                                    $jumlahDiperlukan = json_decode($request->jumlah_diperlukan);
                                                                                    $keterangan = json_decode($request->keterangan);
                                                                                ?>
                                                                                <?php for($i = 0; $i < count($namaBarang); $i++): ?>
                                                                                    <tr>
                                                                                        <td><?php echo e($namaBarang[$i]); ?></td>
                                                                                        <td><?php echo e($jumlahHalaman[$i]); ?></td>
                                                                                        <td><?php echo e($jumlahDiperlukan[$i]); ?></td>
                                                                                        <td><?php echo e($keterangan[$i]); ?></td>
                                                                                    </tr>
                                                                                <?php endfor; ?>
                                                                            </tbody>
                                                                        </table>
                                                                    </div>
                                                                </div>
                                                                <?php if($request->approval_history): ?>
                                                                    <div class="row mt-3">
                                                                        <div class="col-12">
                                                                            <h6>Riwayat Approval</h6>
                                                                            <table class="table table-bordered">
                                                                                <thead>
                                                                                    <tr>
                                                                                        <th>Level</th>
                                                                                        <th>Status</th>
                                                                                        <th>Oleh</th>
                                                                                        <th>Tanggal</th>
                                                                                        <th>Catatan</th>
                                                                                    </tr>
                                                                                </thead>
                                                                                <tbody>
                                                                                    <?php $__currentLoopData = json_decode($request->approval_history); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <tr>
                                                                                            <td><?php echo e($history->level); ?></td>
                                                                                            <td>
                                                                                                <?php if($history->status === 'approved'): ?>
                                                                                                    <span class="badge badge-success">Approved</span>
                                                                                                <?php elseif($history->status === 'rejected'): ?>
                                                                                                    <span class="badge badge-danger">Rejected</span>
                                                                                                <?php else: ?>
                                                                                                    <span class="badge badge-warning">Pending</span>
                                                                                                <?php endif; ?>
                                                                                            </td>
                                                                                            <td><?php echo e($history->approver_name); ?></td>
                                                                                            <td><?php echo e($history->timestamp); ?></td>
                                                                                            <td><?php echo e($history->notes ?? '-'); ?></td>
                                                                                        </tr>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </tbody>
                                                                            </table>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Approve Modal -->
                                                <div class="modal fade" id="approveModal<?php echo e($request->id); ?>" tabindex="-1" role="dialog">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <form action="<?php echo e(route('request-fotocopy.approve', $request->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Approve Request</h5>
                                                                    <button type="button" class="close" data-dismiss="modal">
                                                                        <span>&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="form-group">
                                                                        <label>Catatan (Opsional)</label>
                                                                        <textarea name="notes" class="form-control" rows="3"></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                                                    <button type="submit" class="btn btn-success">Approve</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Reject Modal -->
                                                <div class="modal fade" id="rejectModal<?php echo e($request->id); ?>" tabindex="-1" role="dialog">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <form action="<?php echo e(route('request-fotocopy.reject', $request->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Reject Request</h5>
                                                                    <button type="button" class="close" data-dismiss="modal">
                                                                        <span>&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="form-group">
                                                                        <label>Alasan Reject</label>
                                                                        <textarea name="rejected_message" class="form-control" rows="3" required></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                                                    <button type="submit" class="btn btn-danger">Reject</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#request-table').DataTable({
                "responsive": true,
                "autoWidth": false,
                "order": [[0, "desc"]]
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/request-fotocopy/index.blade.php ENDPATH**/ ?>