

<?php $__env->startSection('content-header'); ?>
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h3 class="page-title">Tambah Pengajuan Fotocopy</h3>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item active">Tambah Pengajuan</li>
                </ol>
            </nav>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('request-fotocopy.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="employee_id" value="<?php echo e($employee->id); ?>">

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Nama Lengkap</label>
                        <input type="text" name="nama_lengkap" class="form-control" value="<?php echo e($employee->full_name); ?>"
                            readonly required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Nomor Induk Karyawan</label>
                        <input type="text" name="nomor_induk_karyawan" class="form-control" value="<?php echo e($employee->nik); ?>"
                            readonly required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Unit</label>
                        <input type="text" name="unit" class="form-control" value="<?php echo e($employee->unit); ?>" readonly
                            required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Divisi</label>
                        <input type="text" name="divisi" class="form-control" value="<?php echo e($employee->division); ?>" readonly
                            required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Status Karyawan</label>
                        <input type="text" name="status_karyawan" class="form-control"
                            value="<?php echo e($employee->employee_status); ?>" readonly required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Jabatan</label>
                        <input type="text" name="jabatan" class="form-control" value="<?php echo e($employee->position); ?>" readonly
                            required>
                    </div>
                </div>

                <?php echo $__env->make('pages.request-fotocopy.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="<?php echo e(route('request-fotocopy.index')); ?>" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/request-fotocopy/create.blade.php ENDPATH**/ ?>