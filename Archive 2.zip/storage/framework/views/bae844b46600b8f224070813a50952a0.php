<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Edit Slip Gaji</h3>
    </div>
    <div>
        <a href="<?php echo e(route('payroll.index')); ?>" class="btn btn-secondary">Kembali</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h5>Informasi Karyawan</h5>
                        <table class="table table-borderless">
                            <tr>
                                <td width="150">NIK</td>
                                <td>: <?php echo e($salarySlip->employee->employee_number); ?></td>
                            </tr>
                            <tr>
                                <td>Nama</td>
                                <td>: <?php echo e($salarySlip->employee->full_name); ?></td>
                            </tr>
                            <tr>
                                <td>Jabatan</td>
                                <td>: <?php echo e($salarySlip->employee->position); ?></td>
                            </tr>
                            <tr>
                                <td>Divisi</td>
                                <td>: <?php echo e($salarySlip->employee->division); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h5>Informasi Slip Gaji</h5>
                        <table class="table table-borderless">
                            <tr>
                                <td width="150">Periode</td>
                                <td>: <?php echo e($salarySlip->date->format('F Y')); ?></td>
                            </tr>
                            <tr>
                                <td>Status</td>
                                <td>: <span class="badge bg-<?php echo e($salarySlip->status === 'paid' ? 'success' : 'warning'); ?>">
                                    <?php echo e($salarySlip->status === 'paid' ? 'Dibayar' : 'Belum Dibayar'); ?>

                                </span></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <form action="<?php echo e(route('payroll.update', $salarySlip)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <h5>Komponen Gaji</h5>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Komponen</th>
                                        <th width="200">Jumlah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $salarySlip->components; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $component): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($component->title); ?>

                                                <?php if($component->description): ?>
                                                    <br>
                                                    <small class="text-muted"><?php echo e($component->description); ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="input-group">
                                                    <span class="input-group-text">Rp</span>
                                                    <input type="number" 
                                                           name="components[<?php echo e($component->id); ?>][amount]" 
                                                           value="<?php echo e($component->amount); ?>"
                                                           class="form-control text-end"
                                                           required>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Total</th>
                                        <th class="text-end">Rp <?php echo e(number_format($salarySlip->amount)); ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="notes" class="form-label">Catatan</label>
                                <textarea class="form-control" id="notes" name="notes" rows="3"><?php echo e($salarySlip->notes); ?></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            <a href="<?php echo e(route('payroll.index')); ?>" class="btn btn-secondary">Batal</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/payroll/edit.blade.php ENDPATH**/ ?>