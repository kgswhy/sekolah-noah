<?php $__env->startSection('content-header'); ?>
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Daftar Pengajuan Cuti</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Cuti</li>
                </ol>
            </nav>
        </div>
    </div>
    <div>
        <a href="<?php echo e(route('cuti.create')); ?>" class="btn btn-primary">
            <i class="las la-plus"></i> Ajukan Cuti
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <table id="cutiTable" class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Karyawan</th>
                    <th>NIK</th>
                    <th>Tanggal Cuti</th>
                    <th>Alasan</th>
                    <th>Departemen</th>
                    <th>Status</th>
                    <th>Level Approval</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cutis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($cuti->id); ?></td>
                        <td><?php echo e($cuti->employee->full_name ?? '-'); ?></td>
                        <td><?php echo e($cuti->employee->nik ?? '-'); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($cuti->tanggal_mulai)->format('d-m-Y')); ?> s.d. <?php echo e(\Carbon\Carbon::parse($cuti->tanggal_selesai)->format('d-m-Y')); ?></td>
                        <td><?php echo e($cuti->alasan); ?></td>
                        <td><?php echo e(ucfirst($cuti->department_type)); ?></td>
                        <td>
                            <?php if($cuti->status === 'pending'): ?>
                                <span class="badge bg-warning">Menunggu Persetujuan</span>
                            <?php elseif($cuti->status === 'approved'): ?>
                                <span class="badge bg-success">Disetujui</span>
                                <?php if($cuti->approved_by): ?>
                                    <br>
                                    <small class="text-muted">
                                        Oleh: <?php echo e($cuti->approver->name ?? '-'); ?>

                                        <br>
                                        <?php echo e($cuti->approved_at ? \Carbon\Carbon::parse($cuti->approved_at)->format('d-m-Y H:i') : '-'); ?>

                                    </small>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="badge bg-danger">Ditolak</span>
                                <?php if($cuti->rejected_by): ?>
                                    <br>
                                    <small class="text-muted">
                                        Oleh: <?php echo e($cuti->rejector->name ?? '-'); ?>

                                        <br>
                                        <?php echo e($cuti->rejected_at ? \Carbon\Carbon::parse($cuti->rejected_at)->format('d-m-Y H:i') : '-'); ?>

                                    </small>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($cuti->status === 'pending'): ?>
                                Level <?php echo e($cuti->current_approval_level); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('cuti.show', $cuti->id)); ?>" class="btn btn-info btn-sm">
                                <i class="las la-eye"></i> Detail
                            </a>
                            <?php if($cuti->status === 'pending'): ?>
                                <?php if(Auth::user()->isApproverFor('cuti', $cuti->current_approval_level, $cuti->department_type)): ?>
                                    <a href="<?php echo e(route('cuti.approve', $cuti->id)); ?>" class="btn btn-success btn-sm">
                                        <i class="las la-check"></i> Terima
                                    </a>
                                    <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#rejectModal-<?php echo e($cuti->id); ?>">
                                        <i class="las la-times"></i> Tolak
                                    </button>

                                    <!-- Reject Modal -->
                                    <div class="modal fade" id="rejectModal-<?php echo e($cuti->id); ?>" tabindex="-1" aria-labelledby="rejectModalLabel-<?php echo e($cuti->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('cuti.reject', $cuti->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="rejectModalLabel-<?php echo e($cuti->id); ?>">Tolak Pengajuan Cuti</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label for="rejected_message" class="form-label">Alasan Penolakan</label>
                                                            <textarea class="form-control" id="rejected_message" name="rejected_message" rows="3" required></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                        <button type="submit" class="btn btn-danger">Tolak</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#cutiTable').DataTable({
            responsive: true,
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Indonesian.json'
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts/master-dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/Kgswahyu/Documents/Project/sekolah-noah/resources/views/pages/cuti/index.blade.php ENDPATH**/ ?>