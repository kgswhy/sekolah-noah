<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PengajuanFotocopy extends Model
{
    protected $table = "pengajuan_fotocopy";

    protected $fillable = [
        'nama_lengkap',
        'nomor_induk_karyawan',
        'unit',
        'divisi',
        'status_karyawan',
        'jabatan',
        'kegiatan',
        'subject',
        'kelas',
        'tanggal_penggunaan',
        'nama_barang',
        'jumlah_halaman',
        'jumlah_diperlukan',
        'keterangan',
    ];
    
    protected $casts = [
        'nama_barang' => 'array',
        'jumlah_halaman' => 'array',
        'jumlah_diperlukan' => 'array',
        'keterangan' => 'array',
    ];    
}
