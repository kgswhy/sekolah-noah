<?php

namespace App\Http\Controllers;

use App\Models\PengajuanFotocopy;
use Illuminate\Http\Request;

class PengajuanFotocopyController extends Controller {

    public function index()
    {
        $pengajuanFotocopy = PengajuanFotocopy::all();
        return view('pages.request-fotocopy.index', compact('pengajuanFotocopy'));
    }

    public function create()
    {
        return view('pages.request-fotocopy.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_lengkap' => 'required|string|max:255',
            'nomor_induk_karyawan' => 'required|string|max:255',
            'unit' => 'required|string|max:255',
            'divisi' => 'required|string|max:255',
            'status_karyawan' => 'required|string|max:255',
            'jabatan' => 'required|string|max:255',
            'kegiatan' => 'required|string|max:255',
            'subject' => 'required|string|max:255',
            'kelas' => 'required|string|max:255',
            'tanggal_penggunaan' => 'required|date',
            'nama_barang' => 'required|array',
            'jumlah_halaman' => 'required|array',
            'jumlah_diperlukan' => 'required|array',
            'keterangan' => 'required|array',
        ]);

        PengajuanFotocopy::create($request->all());

        return redirect()->route('request-fotocopy.index')->with('success', 'Pengajuan fotocopy berhasil ditambahkan!');
    }

    public function edit($id)
    {
        $pengajuanFotocopy = PengajuanFotocopy::findOrFail($id);
        return view('pages.request-fotocopy.edit', compact('pengajuanFotocopy'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nama_lengkap' => 'required|string|max:255',
            'nomor_induk_karyawan' => 'required|string|max:255',
            'unit' => 'required|string|max:255',
            'divisi' => 'required|string|max:255',
            'status_karyawan' => 'required|string|max:255',
            'jabatan' => 'required|string|max:255',
            'kegiatan' => 'required|string|max:255',
            'subject' => 'required|string|max:255',
            'kelas' => 'required|string|max:255',
            'tanggal_penggunaan' => 'required|date',
            'nama_barang' => 'required|array',
            'jumlah_halaman' => 'required|array',
            'jumlah_diperlukan' => 'required|array',
            'keterangan' => 'required|array',
        ]);

        $pengajuanFotocopy = PengajuanFotocopy::findOrFail($id);
        $pengajuanFotocopy->update($request->all());

        return redirect()->route('request-fotocopy.index')->with('success', 'Pengajuan fotocopy berhasil diupdate!');
    }

    public function destroy($id)
    {
        $pengajuanFotocopy = PengajuanFotocopy::findOrFail($id);
        $pengajuanFotocopy->delete();

        return redirect()->route('request-fotocopy.index')->with('success', 'Pengajuan fotocopy berhasil dihapus!');
    }

}
