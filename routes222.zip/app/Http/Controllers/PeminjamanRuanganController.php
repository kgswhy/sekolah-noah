<?php

namespace App\Http\Controllers\Operasional;

use App\Http\Controllers\Controller;
use App\Models\PeminjamanRuangan;
use Illuminate\Http\Request;

class PeminjamanRuanganController extends Controller
{
    public function index()
    {
        $peminjamanRuangan = PeminjamanRuangan::all();
        return view('pages.peminjaman-ruangan.index', compact('peminjamanRuangan'));
    }

    public function create()
    {
        return view('pages.peminjaman-ruangan.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_karyawan' => 'required|string',
            'tanggal_pengajuan' => 'required|date',
            'tanggal_diperlukan' => 'required|date',
            'waktu_pelaksanaan' => 'required|string',
            'unit' => 'required|string',
            'departemen' => 'required|string',
            'nama_kegiatan' => 'required|string',
            'tempat_kegiatan' => 'required|string',
            'ruangan.*' => 'required|string',
            'jumlah.*' => 'required|integer|min:1',
            'keterangan.*' => 'nullable|string',
        ]);

        $peminjaman = PeminjamanRuangan::create($request->only([
            'nama_karyawan', 'tanggal_pengajuan', 'tanggal_diperlukan',
            'waktu_pelaksanaan', 'unit', 'departemen', 'nama_kegiatan', 'tempat_kegiatan'
        ]) + [
            'ruangan' => json_encode($request->ruangan),
            'jumlah' => json_encode($request->jumlah),
            'keterangan' => json_encode($request->keterangan)
        ]);

        return redirect()->route('peminjaman.index')->with('success', 'Peminjaman Ruangan berhasil disimpan!');
    }

    public function edit($id)
    {
        $peminjaman = PeminjamanRuangan::findOrFail($id);
        return view('pages.peminjaman-ruangan.edit', compact('peminjaman'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nama_karyawan' => 'required|string',
            'tanggal_pengajuan' => 'required|date',
            'tanggal_diperlukan' => 'required|date',
            'waktu_pelaksanaan' => 'required|string',
            'unit' => 'required|string',
            'departemen' => 'required|string',
            'nama_kegiatan' => 'required|string',
            'tempat_kegiatan' => 'required|string',
            'ruangan.*' => 'required|string',
            'jumlah.*' => 'required|integer|min:1',
            'keterangan.*' => 'nullable|string',
        ]);

        $peminjaman = PeminjamanRuangan::findOrFail($id);
        $peminjaman->update($request->only([
            'nama_karyawan', 'tanggal_pengajuan', 'tanggal_diperlukan',
            'waktu_pelaksanaan', 'unit', 'departemen', 'nama_kegiatan', 'tempat_kegiatan'
        ]) + [
            'ruangan' => json_encode($request->ruangan),
            'jumlah' => json_encode($request->jumlah),
            'keterangan' => json_encode($request->keterangan)
        ]);

        return redirect()->route('peminjaman.index')->with('success', 'Peminjaman Ruangan berhasil diperbarui!');
    }

    public function destroy($id)
    {
        $peminjaman = PeminjamanRuangan::findOrFail($id);
        $peminjaman->delete();

        return redirect()->route('peminjaman.index')->with('success', 'Peminjaman Ruangan berhasil dihapus!');
    }
}

