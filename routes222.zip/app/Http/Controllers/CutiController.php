<?php

namespace App\Http\Controllers;

use App\Models\Cuti;
use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class CutiController extends Controller
{
    public function create()
    {
        // Retrieve the logged-in user's employee data
        $employee = Auth::user()->employee;  // Assuming User model has a relationship with Employee

        return view('pages.cuti.create', compact('employee'));
    }

    public function store(Request $request)
    {
        // Validate the input data
        $request->validate([
            'tanggal_mulai'  => 'required|date',
            'tanggal_selesai'=> 'required|date',
            'alasan'         => 'required|string',
            'telepon'        => 'required|string',
            'dokumen'        => 'nullable|file|mimes:pdf,jpg,png|max:2048',
        ]);

        // Handle file upload for dokumen
        if ($request->hasFile('dokumen')) {
            $dokumenPath = $request->file('dokumen')->store('dokumen_cuti');
        } else {
            $dokumenPath = null;
        }

        // Store the leave request data in the database
        Cuti::create([
            'employee_id'    => $request->employee_id,  // Associate the leave request with the employee
            'tanggal_mulai'  => $request->tanggal_mulai,
            'tanggal_selesai'=> $request->tanggal_selesai,
            'alasan'         => $request->alasan,
            'keterangan'     => $request->keterangan,
            'dokumen'        => $dokumenPath,
            'telepon'        => $request->telepon,
        ]);

        return redirect('/cuti')->with('success', 'Cuti berhasil diajukan!');
    }

    public function approve($id)
    {
        $cuti = Cuti::findOrFail($id);
        $cuti->status = 'approved';
        $cuti->save();

        return redirect()->route('cuti.index')->with('success', 'Pengajuan cuti disetujui.');
    }

    public function reject(Request $request, $id)
    {
        $request->validate([
            'rejected_message' => 'required|string|max:1000',
        ]);

        $cuti = Cuti::findOrFail($id);
        $cuti->status = 'rejected';
        $cuti->rejected_message = $request->rejected_message;
        $cuti->save();

        return redirect()->route('cuti.index')->with('success', 'Pengajuan cuti telah ditolak dengan pesan.');
    }
}
