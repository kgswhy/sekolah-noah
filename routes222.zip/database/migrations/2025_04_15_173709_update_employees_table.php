<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('employees', function (Blueprint $table) {
            // Hapus kolom yang tidak diperlukan
            $table->dropColumn(['name', 'address', 'phone_number', 'age']);

            // Tambahkan kolom baru
            $table->string('full_name')->after('user_id');
            $table->string('employee_number')->unique()->after('full_name');
            $table->string('unit')->nullable();
            $table->string('division')->nullable();
            $table->string('employment_status')->nullable(); // contoh: kontrak, tetap
            $table->string('position')->nullable();
            $table->string('gender')->nullable();
            $table->string('blood_type')->nullable();
            $table->string('birth_place')->nullable();
            $table->date('birth_date')->nullable();
            $table->string('bpjs_ketenagakerjaan_number')->nullable();
            $table->string('bpjs_kesehatan_number')->nullable();
            $table->string('nik')->nullable(); // Nomor Induk Kependudukan
            $table->string('kk_number')->nullable(); // Nomor Kartu Keluarga
            $table->string('religion')->nullable();
            $table->string('last_education')->nullable();
            $table->text('ktp_address')->nullable();
            $table->text('domicile_address')->nullable();
            $table->string('phone_number')->nullable();
            $table->string('npwp_number')->nullable();
            $table->string('school_email')->nullable();
            $table->string('other_email')->nullable();
            $table->string('marital_status')->nullable(); // contoh: menikah, lajang
            $table->string('employee_status')->default('aktif'); // aktif / tidak aktif
            $table->date('entry_date')->nullable();
            $table->date('exit_date')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('employees', function (Blueprint $table) {
            // Tambahkan kembali kolom lama jika dibutuhkan (opsional)
            $table->dropColumn([
                'full_name',
                'employee_number',
                'unit',
                'division',
                'employment_status',
                'position',
                'gender',
                'blood_type',
                'birth_place',
                'birth_date',
                'bpjs_ketenagakerjaan_number',
                'bpjs_kesehatan_number',
                'nik',
                'kk_number',
                'religion',
                'last_education',
                'ktp_address',
                'domicile_address',
                'phone_number',
                'npwp_number',
                'school_email',
                'other_email',
                'marital_status',
                'employee_status',
                'entry_date',
                'exit_date',
            ]);

            // Kolom lama tidak dikembalikan secara otomatis
            // Tambahkan manual jika diperlukan
        });
    }
};
