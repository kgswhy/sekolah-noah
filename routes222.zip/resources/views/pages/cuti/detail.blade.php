@extends('layouts/master-dashboard')

@section('content-header')
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Detail Pengajuan Cuti</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="/cuti">Cuti</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Detail</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                <th>Nama Lengkap</th>
                <td>Yudha Pratama</td>
            </tr>
            <tr>
                <th>Nomor Induk Karyawan</th>
                <td>1234567890</td>
            </tr>
            <tr>
                <th>Unit</th>
                <td>SD</td>
            </tr>
            <tr>
                <th>Divisi</th>
                <td>Akademik</td>
            </tr>
            <tr>
                <th>Status Karyawan</th>
                <td>Pegawai Tetap</td>
            </tr>
            <tr>
                <th>Jabatan</th>
                <td>IT</td>
            </tr>
            <tr>
                <th>Tanggal Tidak Masuk</th>
                <td>01-04-2025 s.d. 03-04-2025</td>
            </tr>
            <tr>
                <th>Alasan Tidak Masuk</th>
                <td>Cuti</td>
            </tr>
            <tr>
                <th>Keterangan</th>
                <td>Liburan keluarga ke luar kota</td>
            </tr>
            <tr>
                <th>Dokumen Pendukung</th>
                <td>
                    <a href="/storage/dokumen/cuti123.pdf" target="_blank">Lihat Dokumen</a>
                </td>
            </tr>
            <tr>
                <th>No Telpon yang Bisa Dihubungi</th>
                <td>081234567890</td>
            </tr>
        </table>
    </div>
</div>
@endsection
