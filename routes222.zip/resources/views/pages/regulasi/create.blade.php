@extends('layouts/master-dashboard')

@section('content-header')
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Tambah Regulasi</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="/regulasi">Regulasi</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Tambah Regulasi</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
@endsection

@section('content')

<div class="row">
    <div class="col-md-12">
        <!-- Card untuk Form Tambah Regulasi -->
        <div class="card">
            <div class="card-body">
                <form action="/regulasi/create" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label for="judul" class="form-label">Judul Regulasi</label>
                        <input type="text" class="form-control" id="judul" name="judul" required>
                    </div>
                    <div class="mb-3">
                        <label for="isi" class="form-label">Isi Regulasi</label>
                        <textarea class="form-control" id="isi" name="isi" rows="10"></textarea>
                    </div>
                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Simpan Regulasi</button>
                        <a href="/regulasi" class="btn btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

@section('scripts')
<!-- CKEditor 5 CDN -->
<script src="https://cdn.ckeditor.com/ckeditor5/45.0.0/ckeditor5.umd.js"></script>

<script>
    // Inisialisasi CKEditor 5 pada textarea #isi
    ClassicEditor
        .create(document.querySelector('#isi'), {
            toolbar: [
                'undo', 'redo', '|',
                'bold', 'italic', 'underline', '|',
                'fontSize', 'fontFamily', 'fontColor', 'fontBackgroundColor', '|',
                'bulletedList', 'numberedList', '|',
                'outdent', 'indent', '|',
                'link'
            ],
            // Jika perlu, bisa menambahkan konfigurasi tambahan di sini.
        })
        .then(editor => {
            window.editor = editor;  // Menyimpan instance editor jika diperlukan.
        })
        .catch(error => {
            console.error(error);
        });
</script>
@endsection
