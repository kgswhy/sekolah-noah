@extends('layouts/master-dashboard')

@section('content-header')
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Detail Regulasi</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item"><a href="/regulasi">Regulasi</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Detail Regulasi</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="ms-auto">
        <a href="/regulasi/edit/1" class="btn btn-warning">Edit Regulasi</a>
        <a href="/regulasi" class="btn btn-secondary">Kembali</a>
    </div>
</div>
@endsection

@section('content')

<div class="row">
    <div class="col-md-12">
        <!-- Card untuk Detail Regulasi -->
        <div class="card">
            <div class="card-body">
                <!-- Data Dummy Regulasi -->
                <h5><strong>ID:</strong> 1</h5>
                <h5><strong>Judul:</strong> Regulasi Sekolah NOAH</h5>
                <h5><strong>Isi Regulasi:</strong></h5>
                <p>
                    Regulasi Sekolah NOAH ini bertujuan untuk mengatur tata tertib dan prosedur yang harus diikuti oleh seluruh pihak yang terlibat 
                    dalam kegiatan di sekolah, mulai dari siswa, guru, hingga staf administrasi. Adapun beberapa poin penting dalam regulasi ini adalah:
                </p>
                <ul>
                    <li>Langkah 1: Setiap siswa wajib hadir tepat waktu sesuai dengan jadwal pelajaran yang telah ditentukan.</li>
                    <li>Langkah 2: Siswa yang tidak dapat hadir karena alasan tertentu wajib memberikan surat izin atau keterangan yang sah.</li>
                    <li>Langkah 3: Semua kegiatan ekstrakurikuler harus mematuhi prosedur yang telah disepakati dengan pihak sekolah.</li>
                    <li>Langkah 4: Para guru dan staf diharapkan untuk selalu berperilaku profesional dan menjaga lingkungan sekolah yang kondusif.</li>
                </ul>
                <p>
                    Regulasi ini bertujuan untuk menjaga kedisiplinan dan kualitas pendidikan di Sekolah NOAH, sehingga seluruh civitas akademika dapat berfungsi dengan optimal.
                </p>
            </div>
        </div>
    </div>
</div>

@endsection
