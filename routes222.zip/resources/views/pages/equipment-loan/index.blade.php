@extends('layouts/master-dashboard')

@section('header')
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h3 class="page-title">Peminjaman Barang</h3>
            <div class="d-inline-block align-items-center">
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
                        <li class="breadcrumb-item" aria-current="page">IT</li>
                        <li class="breadcrumb-item active" aria-current="page">Peminjaman Barang</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Add Student Button in Header -->
        <div>
            <a href="/it/equipment-loan/create" class="btn btn-primary">Tambah Peminjaman</a>
        </div>
    </div>
@endsection

@section('content')

    <div class="row">
        <div class="col-12">
            <div class="box">
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table mb-0" id="studentTable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nama User</th>
                                    <th scope="col">Tanggal Pengajuan</th>
                                    <th scope="col">Tanggal Diperlukan</th>
                                    <th scope="col">Waktu Pelaksanaan</th>
                                    <th scope="col">Unit</th>
                                    <th scope="col">Departmen / Divisi</th>
                                    <th scope="col">Nama Kegiatan</th>
                                    <th scope="col">Tempat Kegiatan</th>
                                    <th scope="col">Keterangan / Deskripsi Barang</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>

@endsection

@section('scripts')
    <!-- DataTables CDN -->
    <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#studentTable').DataTable({
                // Optional: You can add configurations here for DataTable like pagination, sorting, etc.
                "paging": true,
                "searching": true,
                "ordering": true,
                "info": true
            });
        });
    </script>
@endsection
