@extends('layouts/master-dashboard')

@section('header')
    <div class="d-flex align-items-center">
        <div class="me-auto">
            <h3 class="page-title">Peminjaman Barang</h3>
            <div class="d-inline-block align-items-center">
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"><i class="mdi mdi-home-outline"></i></a></li>
                        <li class="breadcrumb-item" aria-current="page">IT</li>
                        <li class="breadcrumb-item active" aria-current="page">Peminjaman Barang</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
@endsection

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="box">
                <div class="box-body">
                    <form action="#" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <!-- Nama User -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="user_name">Nama User</label>
                                    <input type="text" class="form-control" id="user_name" name="user_name" value="{{ Auth::user()->name }}" readonly>
                                </div>
                            </div>

                            <!-- Tanggal Pengajuan -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="submission_date">Tanggal Pengajuan</label>
                                    <input type="date" class="form-control" id="submission_date" name="submission_date" required>
                                </div>
                            </div>

                            <!-- Tanggal Diperlukan -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="required_date">Tanggal Diperlukan</label>
                                    <input type="date" class="form-control" id="required_date" name="required_date" required>
                                </div>
                            </div>

                            <!-- Waktu Pelaksanaan -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="execution_time">Waktu Pelaksanaan</label>
                                    <input type="time" class="form-control" id="execution_time" name="execution_time" required>
                                </div>
                            </div>

                            <!-- Unit -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="unit">Unit</label>
                                    <input type="text" class="form-control" id="unit" name="unit" required>
                                </div>
                            </div>

                            <!-- Departmen / Divisi -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="division">Departmen / Divisi</label>
                                    <input type="text" class="form-control" id="division" name="division" required>
                                </div>
                            </div>

                            <!-- Nama Kegiatan -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="activity_name">Nama Kegiatan</label>
                                    <input type="text" class="form-control" id="activity_name" name="activity_name" required>
                                </div>
                            </div>

                            <!-- Tempat Kegiatan -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="activity_location">Tempat Kegiatan</label>
                                    <input type="text" class="form-control" id="activity_location" name="activity_location" required>
                                </div>
                            </div>

                            <!-- Barang yang Dipinjam -->
                            <div class="col-md-12">
                                <h5>Barang Yang Dipinjam</h5>
                                <div class="repeated-items">
                                    <div class="item">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="item_name">Nama Barang</label>
                                                    <input type="text" class="form-control" name="item_name[]" required>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="item_quantity">Jumlah Barang</label>
                                                    <input type="number" class="form-control" name="item_quantity[]" required>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="item_description">Keterangan</label>
                                                    <input type="text" class="form-control" name="item_description[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-secondary add-item">Tambah Barang</button>
                            </div>

                            <!-- Submit Button -->
                            <div class="col-md-12 mt-3">
                                <button type="submit" class="btn btn-primary">Kirim Request</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Script to dynamically add item fields for multiple items -->
    <script>
        document.querySelector('.add-item').addEventListener('click', function () {
            let itemHTML = `
                <div class="item mt-3">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="item_name">Nama Barang</label>
                                <input type="text" class="form-control" name="item_name[]" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="item_quantity">Jumlah Barang</label>
                                <input type="number" class="form-control" name="item_quantity[]" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="item_description">Keterangan</label>
                                <input type="text" class="form-control" name="item_description[]">
                            </div>
                        </div>
                    </div>
                </div>`;
            document.querySelector('.repeated-items').insertAdjacentHTML('beforeend', itemHTML);
        });
    </script>
@endsection
