@extends('layouts/master-dashboard')

@section('content-header')
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Ajukan Klaim Berobat Jalan</h3>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                <li class="breadcrumb-item"><a href="/klaim-berobat">Klaim Berobat Jalan</a></li>
                <li class="breadcrumb-item active">Ajukan Klaim</li>
            </ol>
        </nav>
    </div>
</div>
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <form>
            <h5>Data Pegawai</h5>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label>Nama Lengkap</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-4 mb-3">
                    <label>Nomor Induk Karyawan</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-4 mb-3">
                    <label>Unit</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label>Divisi</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-3 mb-3">
                    <label>Status Karyawan</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-3 mb-3">
                    <label>Jabatan</label>
                    <input type="text" class="form-control">
                </div>
            </div>

            <hr>
            <h5>Data Pasien</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label>Nama Pasien</label>
                    <input type="text" class="form-control" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label>Hubungan dengan Pegawai</label>
                    <select class="form-select" required>
                        <option selected disabled>Pilih</option>
                        <option>Suami/Istri</option>
                        <option>Anak</option>
                        <option>Orang Tua</option>
                        <option>Lainnya</option>
                    </select>
                </div>
                <div class="col-md-3 mb-3">
                    <label>Tanggal Lahir Pasien</label>
                    <input type="date" class="form-control" required>
                </div>
            </div>

            <hr>
            <h5>Rincian Klaim</h5>
            <div class="table-responsive mb-3">
                <table class="table table-bordered" id="rincianTable">
                    <thead>
                        <tr>
                            <th style="width: 35%">Keterangan</th>
                            <th style="width: 25%">Lampiran</th>
                            <th style="width: 20%">Nominal (Rp)</th>
                            <th style="width: 10%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><input type="text" class="form-control" name="keterangan[]"></td>
                            <td><input type="file" class="form-control" name="lampiran[]"></td>
                            <td><input type="number" class="form-control" name="nominal[]"></td>
                            <td class="text-center">
                                <button type="button" class="btn btn-danger btn-sm" onclick="hapusBaris(this)">Hapus</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <button type="button" class="btn btn-secondary btn-sm" onclick="tambahBaris()">+ Tambah Rincian</button>
            </div>

            <div class="mb-3">
                <button type="submit" class="btn btn-primary">Kirim Klaim</button>
                <a href="/klaim-berobat" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</div>
@endsection

@section('scripts')
<script>
    function tambahBaris() {
        const table = document.getElementById('rincianTable').getElementsByTagName('tbody')[0];
        const newRow = table.rows[0].cloneNode(true);
        newRow.querySelectorAll('input').forEach(input => input.value = '');
        table.appendChild(newRow);
    }

    function hapusBaris(button) {
        const row = button.closest('tr');
        const table = row.parentNode;
        if (table.rows.length > 1) {
            table.removeChild(row);
        } else {
            alert("Minimal satu rincian harus ada.");
        }
    }
</script>
@endsection
