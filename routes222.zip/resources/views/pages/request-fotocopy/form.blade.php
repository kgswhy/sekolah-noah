<div class="row">
    @php $data = isset($pengajuanFotocopy) ? $pengajuanFotocopy : null; @endphp

    <div class="col-md-6 mb-3">
        <label>Nama Lengkap</label>
        <input type="text" name="nama_lengkap" class="form-control" value="{{ old('nama_lengkap', $data->nama_lengkap ?? '') }}" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Nomor Induk Karyawan</label>
        <input type="text" name="nomor_induk_karyawan" class="form-control" value="{{ old('nomor_induk_karyawan', $data->nomor_induk_karyawan ?? '') }}" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Unit</label>
        <input type="text" name="unit" class="form-control" value="{{ old('unit', $data->unit ?? '') }}" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Divisi</label>
        <input type="text" name="divisi" class="form-control" value="{{ old('divisi', $data->divisi ?? '') }}" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Status Karyawan</label>
        <input type="text" name="status_karyawan" class="form-control" value="{{ old('status_karyawan', $data->status_karyawan ?? '') }}" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Jabatan</label>
        <input type="text" name="jabatan" class="form-control" value="{{ old('jabatan', $data->jabatan ?? '') }}" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Kegiatan</label>
        <input type="text" name="kegiatan" class="form-control" value="{{ old('kegiatan', $data->kegiatan ?? '') }}" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Subject</label>
        <input type="text" name="subject" class="form-control" value="{{ old('subject', $data->subject ?? '') }}" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Kelas</label>
        <input type="text" name="kelas" class="form-control" value="{{ old('kelas', $data->kelas ?? '') }}" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Tanggal Penggunaan</label>
        <input type="date" name="tanggal_penggunaan" class="form-control" value="{{ old('tanggal_penggunaan', $data->tanggal_penggunaan ?? '') }}" required>
    </div>

    {{-- Bagian input array --}}
    <div class="col-12 mb-3">
        <label>Nama Barang, Jumlah Halaman, Jumlah Diperlukan, Keterangan</label>
        <div id="items-container">
            @php
                $barangs = old('nama_barang', $data->nama_barang ?? []);
                $halamans = old('jumlah_halaman', $data->jumlah_halaman ?? []);
                $jumlahs = old('jumlah_diperlukan', $data->jumlah_diperlukan ?? []);
                $keterangans = old('keterangan', $data->keterangan ?? []);
            @endphp

            @for($i = 0; $i < max(1, count($barangs)); $i++)
                <div class="row mb-2 item-row">
                    <div class="col-md-3"><input type="text" name="nama_barang[]" class="form-control" placeholder="Nama Barang" value="{{ $barangs[$i] ?? '' }}"></div>
                    <div class="col-md-2"><input type="number" name="jumlah_halaman[]" class="form-control" placeholder="Hal." value="{{ $halamans[$i] ?? '' }}"></div>
                    <div class="col-md-2"><input type="number" name="jumlah_diperlukan[]" class="form-control" placeholder="Jumlah" value="{{ $jumlahs[$i] ?? '' }}"></div>
                    <div class="col-md-4"><input type="text" name="keterangan[]" class="form-control" placeholder="Keterangan" value="{{ $keterangans[$i] ?? '' }}"></div>
                    <div class="col-md-1"><button type="button" class="btn btn-danger btn-sm remove-item">X</button></div>
                </div>
            @endfor
        </div>
        <button type="button" id="add-item" class="btn btn-sm btn-success">+ Tambah</button>
    </div>
</div>

<script>
    document.getElementById('add-item').addEventListener('click', function () {
        let container = document.getElementById('items-container');
        let row = document.createElement('div');
        row.className = 'row mb-2 item-row';
        row.innerHTML = `
            <div class="col-md-3"><input type="text" name="nama_barang[]" class="form-control" placeholder="Nama Barang"></div>
            <div class="col-md-2"><input type="number" name="jumlah_halaman[]" class="form-control" placeholder="Hal."></div>
            <div class="col-md-2"><input type="number" name="jumlah_diperlukan[]" class="form-control" placeholder="Jumlah"></div>
            <div class="col-md-4"><input type="text" name="keterangan[]" class="form-control" placeholder="Keterangan"></div>
            <div class="col-md-1"><button type="button" class="btn btn-danger btn-sm remove-item">X</button></div>
        `;
        container.appendChild(row);
    });

    document.addEventListener('click', function (e) {
        if (e.target && e.target.classList.contains('remove-item')) {
            e.target.closest('.item-row').remove();
        }
    });
</script>
