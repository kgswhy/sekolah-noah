@extends('layouts.master-dashboard')

@section('content-header')
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Tambah Pengajuan Fotocopy</h3>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                <li class="breadcrumb-item active">Tambah Pengajuan</li>
            </ol>
        </nav>
    </div>
</div>
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <form action="{{ route('request-fotocopy.store') }}" method="POST">
            @csrf
            @include('pages.request-fotocopy.form')
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ route('request-fotocopy.index') }}" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>
@endsection
