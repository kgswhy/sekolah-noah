@extends('layouts/master-dashboard')

@section('content-header')
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Ajukan Surat Tugas & Perjalanan Dinas</h3>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                <li class="breadcrumb-item"><a href="/surat-tugas">Surat Tugas</a></li>
                <li class="breadcrumb-item active">Form Pengajuan</li>
            </ol>
        </nav>
    </div>
</div>
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <form>
            <h5>Informasi Perjalanan</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label>Tujuan Tugas</label>
                    <input type="text" class="form-control" name="tujuan_tugas" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Lama Tugas</label>
                    <input type="text" class="form-control" name="lama_tugas" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label>Alat Transportasi</label>
                    <input type="text" class="form-control" name="transportasi" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label>Tanggal Keberangkatan</label>
                    <input type="date" class="form-control" name="tanggal_berangkat" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label>Tanggal Kepulangan</label>
                    <input type="date" class="form-control" name="tanggal_pulang" required>
                </div>
                <div class="col-md-12 mb-3">
                    <label>Penginapan</label>
                    <input type="text" class="form-control" name="penginapan" required>
                </div>
                <div class="col-md-12 mb-3">
                    <label>Deskripsi Tambahan</label>
                    <textarea class="form-control" name="deskripsi_tambahan" rows="3"></textarea>
                </div>
            </div>

            <hr>
            <h5>List Pegawai yang Ditugaskan</h5>
            <table class="table table-bordered" id="pegawaiTable">
                <thead>
                    <tr>
                        <th>Nama Pegawai</th>
                        <th>Jabatan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="text" class="form-control" name="nama_pegawai[]" required></td>
                        <td><input type="text" class="form-control" name="jabatan_pegawai[]" required></td>
                        <td class="text-center">
                            <button type="button" class="btn btn-danger btn-sm removeRow">🗑️</button>
                        </td>
                    </tr>
                </tbody>
            </table>
            <button type="button" class="btn btn-success btn-sm mb-3" id="addRow">+ Tambah Pegawai</button>

            <hr>
            <h5>Dokumen Upload</h5>
            <div class="mb-3">
                <label>Surat Tugas</label>
                <input type="file" class="form-control" name="surat_tugas">
            </div>
            <div class="mb-3">
                <label>Rencana Kegiatan dan Kebutuhan</label>
                <input type="file" class="form-control" name="rencana_kegiatan">
            </div>
            <div class="mb-3">
                <label>Dokumen Pendukung</label>
                <input type="file" class="form-control" name="dokumen_pendukung">
            </div>
            <div class="mb-3">
                <label>Laporan Perjalanan Dinas</label>
                <input type="file" class="form-control" name="laporan_dinas">
            </div>

            <div class="mb-3">
                <button type="submit" class="btn btn-primary">Ajukan</button>
                <a href="/surat-tugas" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</div>
@endsection

@section('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const tableBody = document.querySelector('#pegawaiTable tbody');
        const addRowBtn = document.getElementById('addRow');

        addRowBtn.addEventListener('click', function () {
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td><input type="text" class="form-control" name="nama_pegawai[]" required></td>
                <td><input type="text" class="form-control" name="jabatan_pegawai[]" required></td>
                <td class="text-center">
                    <button type="button" class="btn btn-danger btn-sm removeRow">🗑️</button>
                </td>
            `;
            tableBody.appendChild(newRow);
        });

        tableBody.addEventListener('click', function (e) {
            if (e.target.classList.contains('removeRow')) {
                const row = e.target.closest('tr');
                if (tableBody.rows.length > 1) {
                    row.remove();
                } else {
                    alert("Minimal satu pegawai harus diisi.");
                }
            }
        });
    });
</script>
@endsection
