@extends('layouts/master-dashboard')

@section('content-header')
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Ajukan Permintaan Slip Gaji / Surat Keterangan Kerja</h3>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                <li class="breadcrumb-item"><a href="/slip-gaji-skk">Permintaan Slip Gaji / SKK</a></li>
                <li class="breadcrumb-item active">Ajukan Permintaan</li>
            </ol>
        </nav>
    </div>
</div>
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <form>
            <h5>Data Pegawai</h5>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label>Nama Lengkap</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-4 mb-3">
                    <label>Nomor Induk Karyawan</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-4 mb-3">
                    <label>Unit</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label>Divisi</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-3 mb-3">
                    <label>Status Karyawan</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-3 mb-3">
                    <label>Jabatan</label>
                    <input type="text" class="form-control">
                </div>
            </div>

            <hr>
            <h5>Permintaan</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label>Keperluan</label>
                    <select class="form-select" required>
                        <option selected disabled>Pilih Keperluan</option>
                        <option>Slip Gaji</option>
                        <option>Surat Keterangan Kerja</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Keterangan</label>
                    <textarea class="form-control" rows="3" required></textarea>
                </div>
            </div>

            <div class="mb-3">
                <label>Dokumen Pendukung (Surat Permohonan)</label>
                <input type="file" class="form-control">
            </div>

            <div class="mb-3">
                <button type="submit" class="btn btn-primary">Kirim Permintaan</button>
                <a href="/slip-gaji-skk" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</div>
@endsection
