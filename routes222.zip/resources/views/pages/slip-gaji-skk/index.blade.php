@extends('layouts/master-dashboard')

@section('content-header')
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Permintaan Slip Gaji / Surat Keterangan Kerja</h3>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                <li class="breadcrumb-item active">Permintaan Slip Gaji / SKK</li>
            </ol>
        </nav>
    </div>
    <div class="ms-auto">
        <a href="/slip-gaji-skk/create" class="btn btn-primary">Ajukan Permintaan</a>
    </div>
</div>
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <table class="table table-bordered" id="slipGajiTable">
            <thead>
                <tr>
                    <th>Nama Pegawai</th>
                    <th>Nomor Induk</th>
                    <th>Unit</th>
                    <th>Divisi</th>
                    <th>Status</th>
                    <th>Jabatan</th>
                    <th>Keperluan</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Ahmad Fauzi</td>
                    <td>EMP201</td>
                    <td>Kantor Pusat</td>
                    <td>Finance</td>
                    <td>Tetap</td>
                    <td>Akuntan</td>
                    <td>Slip Gaji Bulanan</td>
                    <td>
                        <a href="#" class="btn btn-warning btn-sm">Edit</a>
                        <a href="#" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?');">Delete</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
@endsection

@section('scripts')
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function () {
        $('#slipGajiTable').DataTable();
    });
</script>
@endsection
