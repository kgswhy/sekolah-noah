@extends('layouts/master-dashboard')

@section('content-header')
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Tambah Karyawan</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item" aria-current="page">HRD</li>
                    <li class="breadcrumb-item active" aria-current="page">Tambah Karyawan</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
@endsection

@section('content')

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <form action="/employee/create" method="POST">
                    @csrf
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" name="full_name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor Induk Karyawan</label>
                            <input type="text" class="form-control" name="employee_number" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Unit</label>
                            <input type="text" class="form-control" name="unit">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Divisi</label>
                            <input type="text" class="form-control" name="division">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status Karyawan</label>
                            <input type="text" class="form-control" name="employment_status">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Jabatan</label>
                            <input type="text" class="form-control" name="position">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Jenis Kelamin</label>
                            <select class="form-control" name="gender">
                                <option value="">-- Pilih --</option>
                                <option value="Laki-laki">Laki-laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Golongan Darah</label>
                            <input type="text" class="form-control" name="blood_type">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tempat Lahir</label>
                            <input type="text" class="form-control" name="birth_place">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Lahir</label>
                            <input type="date" class="form-control" name="birth_date">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor BPJS Ketenagakerjaan</label>
                            <input type="text" class="form-control" name="bpjs_ketenagakerjaan_number">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor BPJS Kesehatan</label>
                            <input type="text" class="form-control" name="bpjs_kesehatan_number">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor Induk Kependudukan (NIK)</label>
                            <input type="text" class="form-control" name="nik">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor Kartu Keluarga (KK)</label>
                            <input type="text" class="form-control" name="kk_number">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Agama</label>
                            <input type="text" class="form-control" name="religion">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Pendidikan Terakhir</label>
                            <input type="text" class="form-control" name="last_education">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Alamat KTP</label>
                            <textarea class="form-control" name="ktp_address"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Alamat Domisili</label>
                            <textarea class="form-control" name="domicile_address"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor Telepon</label>
                            <input type="text" class="form-control" name="phone_number">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor NPWP</label>
                            <input type="text" class="form-control" name="npwp_number">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email Sekolah</label>
                            <input type="email" class="form-control" name="school_email">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email Lainnya</label>
                            <input type="email" class="form-control" name="other_email">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status Perkawinan</label>
                            <input type="text" class="form-control" name="marital_status">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status Pegawai</label>
                            <select class="form-control" name="employee_status">
                                <option value="aktif">Aktif</option>
                                <option value="tidak aktif">Tidak Aktif</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Masuk</label>
                            <input type="date" class="form-control" name="entry_date">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Keluar</label>
                            <input type="date" class="form-control" name="exit_date">
                        </div>
                        <div class="col-12 mt-3">
                            <button type="submit" class="btn btn-primary">Simpan Karyawan</button>
                            <a href="{{ route('employee.index') }}" class="btn btn-secondary">Batal</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
