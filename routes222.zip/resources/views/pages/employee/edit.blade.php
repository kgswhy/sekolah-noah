@extends('layouts/master-dashboard')

@section('content-header')
<div class="d-flex align-items-center">
    <div class="me-auto">
        <h3 class="page-title">Edit Karyawan</h3>
        <div class="d-inline-block align-items-center">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><i class="las la-home"></i></a></li>
                    <li class="breadcrumb-item" aria-current="page">HRD</li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Karyawan</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
@endsection

@section('content')

<div class="row">
    <div class="col-md-12">
        <!-- Card untuk Form Edit Karyawan -->
        <div class="card">
            <div class="card-body">
                <form action="/employee/edit/{{ $employee->id }}" method="POST">
                    @csrf
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" name="full_name" value="{{ $employee->full_name }}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor Induk Karyawan</label>
                            <input type="text" class="form-control" name="employee_number" value="{{ $employee->employee_number }}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Unit</label>
                            <input type="text" class="form-control" name="unit" value="{{ $employee->unit }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Divisi</label>
                            <input type="text" class="form-control" name="division" value="{{ $employee->division }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Jabatan</label>
                            <input type="text" class="form-control" name="position" value="{{ $employee->position }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status Karyawan</label>
                            <input type="text" class="form-control" name="employment_status" value="{{ $employee->employment_status }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Jenis Kelamin</label>
                            <select name="gender" class="form-control">
                                <option value="Laki-laki" {{ $employee->gender == 'Laki-laki' ? 'selected' : '' }}>Laki-laki</option>
                                <option value="Perempuan" {{ $employee->gender == 'Perempuan' ? 'selected' : '' }}>Perempuan</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Golongan Darah</label>
                            <input type="text" class="form-control" name="blood_type" value="{{ $employee->blood_type }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tempat Lahir</label>
                            <input type="text" class="form-control" name="birth_place" value="{{ $employee->birth_place }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Lahir</label>
                            <input type="date" class="form-control" name="birth_date" value="{{ $employee->birth_date }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">No. BPJS Ketenagakerjaan</label>
                            <input type="text" class="form-control" name="bpjs_ketenagakerjaan_number" value="{{ $employee->bpjs_ketenagakerjaan_number }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">No. BPJS Kesehatan</label>
                            <input type="text" class="form-control" name="bpjs_kesehatan_number" value="{{ $employee->bpjs_kesehatan_number }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">NIK</label>
                            <input type="text" class="form-control" name="nik" value="{{ $employee->nik }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">No. Kartu Keluarga</label>
                            <input type="text" class="form-control" name="kk_number" value="{{ $employee->kk_number }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Agama</label>
                            <input type="text" class="form-control" name="religion" value="{{ $employee->religion }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Pendidikan Terakhir</label>
                            <input type="text" class="form-control" name="last_education" value="{{ $employee->last_education }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Alamat KTP</label>
                            <input type="text" class="form-control" name="ktp_address" value="{{ $employee->ktp_address }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Alamat Domisili</label>
                            <input type="text" class="form-control" name="domicile_address" value="{{ $employee->domicile_address }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nomor Telepon</label>
                            <input type="text" class="form-control" name="phone_number" value="{{ $employee->phone_number }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">NPWP</label>
                            <input type="text" class="form-control" name="npwp_number" value="{{ $employee->npwp_number }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email Sekolah</label>
                            <input type="email" class="form-control" name="school_email" value="{{ $employee->school_email }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email Lainnya</label>
                            <input type="email" class="form-control" name="other_email" value="{{ $employee->other_email }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status Perkawinan</label>
                            <input type="text" class="form-control" name="marital_status" value="{{ $employee->marital_status }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status Pegawai</label>
                            <select name="employee_status" class="form-control">
                                <option value="aktif" {{ $employee->employee_status == 'aktif' ? 'selected' : '' }}>Aktif</option>
                                <option value="tidak aktif" {{ $employee->employee_status == 'tidak aktif' ? 'selected' : '' }}>Tidak Aktif</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Masuk</label>
                            <input type="date" class="form-control" name="entry_date" value="{{ $employee->entry_date }}">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Keluar</label>
                            <input type="date" class="form-control" name="exit_date" value="{{ $employee->exit_date }}">
                        </div>
                    </div>
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        <a href="{{ route('employee.index') }}" class="btn btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
