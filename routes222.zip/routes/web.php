<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PagesController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\SalaryComponentController;
use App\Http\Controllers\ShiftController;
use App\Http\Controllers\ScheduleController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CutiController;
use App\Http\Controllers\FixingRequestController;
use App\Http\Controllers\StudentRegistrationController;
use App\Http\Controllers\AdmissionActivityController;
use App\Http\Controllers\BarangController;
use App\Http\Controllers\PengecekanBarangController;
use App\Http\Controllers\OperationalRequestController;
use App\Http\Controllers\PengajuanFotocopyController;
use App\Http\Controllers\PeminjamanController;


Route::get('/login', [PagesController::class, 'loginPage'])->name('login');

Route::post('/login', [AuthController::class, 'login']);

Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

Route::group(['middleware' => 'auth'], function(){

    Route::get('/', function () {
        return view('welcome');
    });

    Route::get('/dashboard', [PagesController::class, 'dashboardPage'])->name('dashboard');

    Route::get('/students', [PagesController::class, 'studentsPage'])->name('students.index');

    Route::get('/students/create', [PagesController::class, 'createStudentPage'])->name('students.create');

    Route::post('/students/create', [StudentController::class, 'createStudent'])->name('students.store');

    Route::get('/students/edit/{id}', [PagesController::class, 'editStudentPage'])->name('students.edit');

    Route::post('/students/edit/{id}', [StudentController::class, 'updateStudent'])->name('students.update');

    Route::delete('/students/delete/{id}', [StudentController::class, 'destroy'])->name('students.destroy');

    Route::get('/students/show/{id}', [PagesController::class, 'showDetailStudent'])->name('students.show');

    Route::get('/it/fixing-request', [PagesController::class, 'fixingRequestPage'])->name('fixing-request.index');

    Route::get('/it/fixing-request/create', [PagesController::class, 'createFixingRequestPage'])->name('fixing-request.create');

    Route::post('/it/fixing-request/create', [FixingRequestController::class, 'store'])->name('fixing-request.store');

    Route::prefix('/it/fixing-request')->group(function () {
        Route::get('{id}/approve', [FixingRequestController::class, 'approve'])->name('fixing-request.approve');
        Route::post('{id}/reject', [FixingRequestController::class, 'reject'])->name('fixing-request.reject');
    });

    Route::get('/it/equipment-loan', [PagesController::class, 'equipmentLoanPage'])->name('equipment-loan.index');

    Route::get('/it/equipment-loan/create', [PagesController::class, 'createEquipmentLoanPage'])->name('equipment-loan.create');

    Route::get('/employee', [PagesController::class, 'employeePage'])->name('employee.index');

    Route::get('/employee/create', [PagesController::class, 'createEmployeePage'])->name('employee.create');

    Route::post('/employee/create', [EmployeeController::class, 'createEmployee'])->name('employee.store');

    Route::get('/employee/edit/{id}', [PagesController::class, 'editEmployeePage'])->name('employee.edit');

    Route::post('/employee/edit/{id}', [EmployeeController::class, 'editEmployee'])->name('employee.update');

    Route::prefix('/employee/{employeeId}')->group(function () {
        Route::get('salary-components', [SalaryComponentController::class, 'index'])->name('salary-components.index');
        Route::get('salary-components/create', [SalaryComponentController::class, 'create'])->name('salary-components.create');
        Route::post('salary-components', [SalaryComponentController::class, 'store'])->name('salary-components.store');
        Route::get('salary-components/{id}/edit', [SalaryComponentController::class, 'edit'])->name('salary-components.edit');
        Route::post('salary-components/{id}', [SalaryComponentController::class, 'update'])->name('salary-components.update');
        Route::get('salary-components/{id}/delete', [SalaryComponentController::class, 'destroy'])->name('salary-components.destroy');
    });

    Route::get('/absence', [PagesController::class, 'absencePage'])->name('absence.index');

    Route::get('/payroll', [PagesController::class, 'payrollPage'])->name('payroll.index');

    Route::resource('shifts', ShiftController::class);

    Route::resource('schedules', ScheduleController::class);

    Route::get('/kinerja', [PagesController::class, 'kinerjaPage'])->name('kinerja.index');
    
    Route::get('/users', [PagesController::class, 'usersPage'])->name('users.index');
    
    Route::get('/users/create', [PagesController::class, 'createUsersPage'])->name('users.create');

    Route::post('/users/create', [UserController::class, 'store'])->name('users.store');

    Route::get('/users/edit/{id}', [UserController::class, 'edit']);
    
    Route::post('/users/update/{id}', [UserController::class, 'update']);

    Route::get('/users/delete/{id}', [UserController::class, 'destroy']);
    
    Route::get('/cuti', [PagesController::class, 'cutiPage'])->name('cuti.index');

    Route::get('/cuti/create', [PagesController::class, 'createCutiPage'])->name('cuti.create');

    Route::get('/cuti/create', [CutiController::class, 'create'])->name('cuti.create');

    Route::post('/cuti/store', [CutiController::class, 'store'])->name('cuti.store');

    Route::get('/cuti/{id}', [PagesController::class, 'detailCutiPage'])->name('cuti.show');

    Route::get('/cuti/{id}/edit', [CutiController::class, 'edit'])->name('cuti.edit');

    Route::delete('/cuti/{id}', [CutiController::class, 'destroy'])->name('cuti.destroy');

    Route::get('/cuti/{id}/approve', [CutiController::class, 'approve'])->name('cuti.approve');
    
    Route::post('/cuti/{id}/reject', [CutiController::class, 'reject'])->name('cuti.reject');

    Route::get('/dms/{divisi}', [PagesController::class, 'dmsPage'])->name('dms.index');

    Route::get('/sop', [PagesController::class, 'sopPage'])->name('sop.index');

    Route::get('/sop/detail/{id}', [PagesController::class, 'detailSopPage'])->name('sop.detail');

    Route::get('/sop/create', [PagesController::class, 'createSopPage'])->name('sop.create');

    Route::get('/regulasi', [PagesController::class, 'regulasiPage'])->name('regulasi.index');

    Route::get('/regulasi/detail/{id}', [PagesController::class, 'detailRegulasiPage'])->name('regulasi.detail');

    Route::get('/regulasi/create', [PagesController::class, 'createRegulasiPage'])->name('regulasi.create');

    Route::prefix('admission')->group(function () {
        Route::get('/pendaftaran', [StudentRegistrationController::class, 'index'])->name('admission.index');
        Route::get('/pendaftaran/create', [StudentRegistrationController::class, 'create'])->name('admission.create');
        Route::post('/pendaftaran', [StudentRegistrationController::class, 'store'])->name('admission.store');
        Route::get('/pendaftaran/edit/{id}', [StudentRegistrationController::class, 'edit'])->name('admission.edit');
        Route::post('/pendaftaran/update/{id}', [StudentRegistrationController::class, 'update'])->name('admission.update');
        Route::get('/pendaftaran/delete/{id}', [StudentRegistrationController::class, 'destroy'])->name('admission.destroy');

        Route::get('/siswa-diterima', [StudentRegistrationController::class, 'accepted'])->name('admission.accepted');
        Route::get('/siswa-tidak-diterima', [StudentRegistrationController::class, 'rejected'])->name('admission.rejected');

        Route::get('/kegiatan', [AdmissionActivityController::class, 'index'])->name('admission.activity.index');
        Route::get('/kegiatan/create', [AdmissionActivityController::class, 'create'])->name('admission.activity.create');
        Route::post('/kegiatan', [AdmissionActivityController::class, 'store'])->name('admission.activity.store');
        Route::get('/kegiatan/edit/{id}', [AdmissionActivityController::class, 'edit'])->name('admission.activity.edit');
        Route::post('/kegiatan/update/{id}', [AdmissionActivityController::class, 'update'])->name('admission.activity.update');
        Route::get('/kegiatan/delete/{id}', [AdmissionActivityController::class, 'destroy'])->name('admission.activity.destroy');
    });

    // web.php (routes)
    Route::prefix('operasional')->group(function () {
        // Barang Routes
        Route::get('/barang', [BarangController::class, 'index'])->name('barang.index');
        Route::get('/barang/create', [BarangController::class, 'create'])->name('barang.create');
        Route::post('/barang', [BarangController::class, 'store'])->name('barang.store');
        Route::get('/barang/edit/{id}', [BarangController::class, 'edit'])->name('barang.edit');
        Route::post('/barang/update/{id}', [BarangController::class, 'update'])->name('barang.update');
        Route::get('/barang/delete/{id}', [BarangController::class, 'destroy'])->name('barang.destroy');

        // Pengecekan Barang Routes
        Route::get('/barang/{id_barang}/pengecekan', [PengecekanBarangController::class, 'index'])->name('pengecekan.index');
        Route::get('/barang/{id_barang}/pengecekan/create', [PengecekanBarangController::class, 'create'])->name('pengecekan.create');
        Route::post('/barang/{id_barang}/pengecekan', [PengecekanBarangController::class, 'store'])->name('pengecekan.store');
        Route::get('/barang/{id_barang}/pengecekan/edit/{id}', [PengecekanBarangController::class, 'edit'])->name('pengecekan.edit');
        Route::post('/barang/{id_barang}/pengecekan/update/{id}', [PengecekanBarangController::class, 'update'])->name('pengecekan.update');
        Route::get('/barang/{id_barang}/pengecekan/delete/{id}', [PengecekanBarangController::class, 'destroy'])->name('pengecekan.destroy');

        Route::get('/kurir-mobil', [OperationalRequestController::class, 'index'])->name('operasional.index');
        Route::get('/kurir-mobil/create', [OperationalRequestController::class, 'create'])->name('operasional.create');
        Route::post('/kurir-mobil', [OperationalRequestController::class, 'store'])->name('operasional.store');
        Route::get('/kurir-mobil/edit/{id}', [OperationalRequestController::class, 'edit'])->name('operasional.edit');
        Route::post('/kurir-mobil/update/{id}', [OperationalRequestController::class, 'update'])->name('operasional.update');
        Route::get('/kurir-mobil/delete/{id}', [OperationalRequestController::class, 'destroy'])->name('operasional.destroy');
    });

    Route::prefix('operasional/peminjaman')->group(function () {
        Route::get('/', [PeminjamanController::class, 'index'])->name('peminjaman.index');
        Route::get('/create', [PeminjamanController::class, 'create'])->name('peminjaman.create');
        Route::post('/store', [PeminjamanController::class, 'store'])->name('peminjaman.store');
        Route::get('/edit/{id}', [PeminjamanController::class, 'edit'])->name('peminjaman.edit');
        Route::post('/update/{id}', [PeminjamanController::class, 'update'])->name('peminjaman.update');
        Route::get('/delete/{id}', [PeminjamanController::class, 'destroy'])->name('peminjaman.delete');
    });
    
    Route::prefix('administrasi/request-fotocopy')->name('request-fotocopy.')->group(function() {
        Route::get('/', [PengajuanFotocopyController::class, 'index'])->name('index');
        Route::get('/create', [PengajuanFotocopyController::class, 'create'])->name('create');
        Route::post('/', [PengajuanFotocopyController::class, 'store'])->name('store');
        Route::get('/{id}/edit', [PengajuanFotocopyController::class, 'edit'])->name('edit');
        Route::put('/{id}', [PengajuanFotocopyController::class, 'update'])->name('update');
        Route::delete('/{id}', [PengajuanFotocopyController::class, 'destroy'])->name('destroy');
    });

    Route::prefix('finance/pembayaran-siswa')->group(function () {
        Route::view('/', 'pages.pembayaran-siswa.index');
        Route::view('/create', 'pages.pembayaran-siswa.create');
    });    

    Route::prefix('finance/aktiva-tetap')->group(function () {
        Route::view('/', 'pages.aktiva-tetap.index');
        Route::view('/create', 'pages.aktiva-tetap.create');
    });  

    Route::prefix('brief-absen')->group(function () {
        Route::view('/', 'pages.izin-brief.index');
        Route::view('/create', 'pages.izin-brief.create');
    });

    Route::prefix('klaim-berobat')->group(function () {
        Route::view('/', 'pages.klaim-berobat.index');
        Route::view('/create', 'pages.klaim-berobat.create');
    });    

    Route::prefix('slip-gaji-skk')->group(function () {
        Route::view('/', 'pages.slip-gaji-skk.index');
        Route::view('/create', 'pages.slip-gaji-skk.create');
    });    

    Route::prefix('pinjaman-cicilan')->group(function () {
        Route::view('/', 'pages.pinjaman-cicilan.index');
        Route::view('/create', 'pages.pinjaman-cicilan.create');
    });    

    Route::prefix('lembur-honor')->group(function () {
        Route::view('/', 'pages.lembur-honor.index');
        Route::view('/create', 'pages.lembur-honor.create');
    });    

    Route::prefix('surat-tugas')->group(function () {
        Route::view('/', 'pages.surat-tugas.index');
        Route::view('/create', 'pages.surat-tugas.create');
    });

    Route::prefix('dashboard/calendar')->group(function () {
        Route::view('/', 'pages.calendar.index');
        Route::view('/create', 'pages.calendar.create');
    });   

    Route::prefix('pengumuman')->group(function () {
        Route::view('/', 'pages.pengumuman.index');
        Route::view('/create', 'pages.pengumuman.create');
    });

    Route::prefix('task')->group(function () {
        Route::view('/', 'pages.task.index');
    });

    Route::prefix('kelas')->group(function() {
        // Route untuk halaman index
        Route::get('/', function () {
            return view('pages.kelas.index');
        });
    
        // Route untuk halaman create
        Route::get('/create', function () {
            return view('pages.kelas.create');
        });
    });
    

});